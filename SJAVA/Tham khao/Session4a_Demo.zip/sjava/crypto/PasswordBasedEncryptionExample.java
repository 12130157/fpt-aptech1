package sjava.crypto;

import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

public class PasswordBasedEncryptionExample {

    public static void main(String[] args) throws Exception {

        PBEKeySpec keyspec = new PBEKeySpec("myVerySecretPw".toCharArray());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
        SecretKey key = keyFactory.generateSecret(keyspec);

        byte[] salt = new byte[8];
        SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
        sr.nextBytes(salt);

        PBEParameterSpec paramSpec = new PBEParameterSpec(salt, 200);

        //Cipher cipher = Cipher.getInstance("PBEWithMD5AndTripleDES/CBC/PKCS5Padding");
        Cipher cipher = Cipher.getInstance("PBEWithMD5AndDES");
        System.out.println("\nStart encryption");
        cipher.init(Cipher.ENCRYPT_MODE, key, paramSpec);

        byte[] plainText = "This is a test!".getBytes("UTF8");
        byte[] cipherText = cipher.doFinal(plainText);
        System.out.println("Finish encryption: ");
        System.out.println(new String(cipherText, "UTF8"));
        
        System.out.println("\nStart decryption");
        cipher.init(Cipher.DECRYPT_MODE, key, paramSpec);
        byte[] newPlainText = cipher.doFinal(cipherText);
        System.out.println("Finish decryption: ");
        System.out.println(new String(newPlainText, "UTF8"));        
    }
}
