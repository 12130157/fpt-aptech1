package ymsg.support;

import java.io.*;
import java.net.URL;
import java.util.*;

/**
 *	Creates emote texts for chat rooms.  Emotes enable shortcut 'action'
 *	messages to be broadcast to a chat room, along the lines of "Waves" or
 *	"Winks".  It is also possible to mention a specific user in an Emote,
 *	although the message still goes to the entire room - for example "Waves
 *	at fred" or "Winks at jenny".  
 *	<p>
 *	Each Emote therefore has a dual form, the 'room' form, and the 'user' 
 *	form.  In the user form, the string "%s" is used as a placeholder 
 *	for the name of the targeted user - for example "Waves at %s" when 
 *	targeted at "jenny" becomes "Waves at jenny".
 *	<p>
 *	Yahoo allows users to add their own Emotes via a configuration file
 *	which is read and appended to the default Emotes Yahoo holds internally.
 *	This class mimics this behaviour, by loading and building lists of Emotes
 *	from various input sources.  The class holds an array of default Emotes.  
 *	When creating an instance, these defaults can either be included or 
 *	ignored.  Any Emotes loaded by this class which share the same name as an
 *	Emote already defined will override the original.
 *	<p>
 *	The standard file format for custom Yahoo Emotes is:
 *	<pre>
 *	# Comment line
 *	&lt;name&gt;\&lt;room form&gt;\&lt;user form&gt;
 *	</pre>
 *	The sequence <i>%s</i> is a placeholder for the target user's name in a
 *	room Emote.  For example:
 *	<pre>
 *	# This is a winks Emote
 *	Winks\Winks.\Winks at %s.
 *	# This is a waves Emote
 *	Waves\Waves at room.\Waves at %s.
 *	</pre>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class EmoteManager
{	/**
	 *	Creates an Emote list from a given file.  The facility to pre-load
	 *	the default Emotes before the file is processed is optional.
	 *
	 *	@param fl		file with emote config
	 *	@param b		true to pre-load default Emotes
	 *	@since			1.0
	 */
	public EmoteManager(File fl,boolean b) {}
	/**
	 *	Creates an Emote list from a given filename.  The facility to pre-load
	 *	the default Emotes before the file is processed is optional.
	 *
	 *	@param fn		file with emote config
	 *	@param b		true to pre-load default Emotes
	 *	@since			1.0
	 */
	public EmoteManager(String fn,boolean b) {}
	/**
	 *	Creates an Emote list from a given URL.  The facility to pre-load
	 *	the default Emotes before the file is processed is optional.
	 *
	 *	@param u		file with emote config
	 *	@param b		true to pre-load default Emotes
	 *	@since			1.0
	 */
	public EmoteManager(URL u,boolean b) {}

	/**
	 *	Returns the loading/parsing errors which occured during creation.
	 *	The <code>Vector</code> holds <code>String</code> objects which
	 *	detail the various errors while attempting to load and parse the
	 *	Emote configurations.  If the vector is empty, no errors occured.
	 *
	 *	@return			Vector of error strings
	 *	@since			1.0
	 */
	public Vector getErrors() {}
	
	/**
	 *	Returns the room version of a given Emote.  Returns null if it doesn't
	 *	exist.
	 *
	 *	@param name		name of Emote
	 *	@return			Emote text, or null
	 *	@since			1.0
	 */
	public String getRoomEmote(String name) {}
	/**
	 *	Returns the user version of a given Emote.  Returns null if it doesn't
	 *	exist.
	 *
	 *	@param name		name of Emote
	 *	@return			Emote text, or null
	 *	@since			1.0
	 */
	public String getUserEmote(String name) {}

	/**
	 *	Returns a list of all Emote names held by this manager.
	 *
	 *	@return			Vector of Emote name strings
	 *	@since			1.0
	 */
	public Vector getNames() {}
	
	/**
	 *	Utility method to combine an Emote string (from <code>getRoomEmote</code>)
	 *	with the supplied username.  Any reference to <code>%s</code> in the 
	 *	Emote string is replaced with the contents of the username string.  
	 *	This method is not fooled by "%s" occurances inside the username string 
	 *	itself.
	 *
	 *	@param	u		target username
	 *	@param	em		Emote text
	 *	@since			1.0
	 */
	public static String encodeEmote(String u,String em) {}
}
