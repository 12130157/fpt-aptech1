package ymsg.network.event;

import ymsg.network.YahooUser;

/**
 *	Fired when friend's details have changed.  Like other events, this one can
 *	be caused by more than one circumstance, and as such the field use is
 *	determined by the type of event.
*	<p>
 *	<table border="2">
 *	<tr><td>&nbsp</td>
 *		<td><b>getFrom</b></td>
 *		<td><b>getFriend</b></td>
 *		<td><b>getFriends</b></td>
 *		<td><b>getGroup</b></td>
 *	</tr>
 *	<tr><td><i>friendsUpdateReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n<sup>[1]</sup></td>
 *	</tr>
 *	<tr><td><i>friendsAddedReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	<tr><td><i>friendsRemoveReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	</table>
 *	<p>
 *	[1] = a friend may be in more than one group - therefore this event is
 *	not specific to one group, unlike other friend events.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SessionFriendEvent extends SessionEvent
{	/**
	 *	Create a new instance. API users should not call this directly. The 
	 *	API itself will create its own events. 
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param sz		number of users
	 *	@since			1.0
	 */
	public SessionFriendEvent(Object o,int sz) {}

	/**
	 *	Create a new instance. API users should not call this directly. The 
	 *	API itself will create its own events. 
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param yu		yahoo user object
	 *	@param gp		group name
	 *	@since			1.0
	 */
	public SessionFriendEvent(Object o,YahooUser yu,String gp) {}
		
	/**
	 *	Returns the list of YahooUser's to whom this event applies.  This
	 *	field is only set when the <code>friendsUpdateReceived</code> event
	 *	method is used.  Otherwise it is <code>null</code>.
	 *
	 *	@return			array of Yahoo user objects
	 *	@since			1.0
	 */	
	public YahooUser[] getFriends() {}

	/**
	 *	Returns the YahooUser to whom this event applies.  This
	 *	field is only set when the <code>friendAddedReceived</code> or 
	 *	<code>friendRemovedReceived</code> event methods are used.  
	 *	Otherwise it is <code>null</code>.
	 *
	 *	@return			yahoo user object
	 *	@since			1.0
	 */
	public YahooUser getFriend() {}

	/**
	 *	Returns the group for which this event applies.  This
	 *	field is only set when the <code>friendAddedReceived</code> or 
	 *	<code>friendRemovedReceived</code> event methods are used.  
	 *	Otherwise it is <code>null</code>.
	 *
	 *	@return			yahoo user object
	 *	@since			1.0
	 */
	public String getGroup() {}

	/**
	 *	Returns the id of a single user relating to this event.  Just
	 *	a shortcut to <code>getFriend().getId()</code>.
	 *
	 *	@return			Yahoo id as a string
	 *	@since			1.0
	 */
	public String getFrom() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 *	@since			1.0
	 */
	public String toString() {}
}
