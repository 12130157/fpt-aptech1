package ymsg.network;

import java.util.Vector;

/**
 *	Represents a single chat room, either public (Yahoo owned) or private
 *	(user owned).  Each room is divided into multiple independent chat
 *	spaces, known as 'lobbies'.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */

public class YahooChatRoom
{	/**
	 *	Returns the name (title) of this chat room.
	 *	
	 *	@return			chatroom name
	 *	@since			1.0
	 */
	public String getName() {}
	/**
	 *	Returns the unique ID used to reference this room.  This is implementation
	 *	detail, and would not normally be needed by API users.
	 *	
	 *	@return			unqiue ID number
	 *	@since			1.0
	 */
	public long getId() {}
	/**
	 *	Returns true if this is a public room, false if private.
	 *	
	 *	@return			true if public room
	 *	@since			1.0
	 */
	public boolean isPublic() {}
	/**
	 *	Returns a list of lobbies for this room.  The list is in the form of a
	 *	<code>Vector</code> of <code>YahooChatLobby</code> objects.  The list
	 *	should never be empty (barring accident!) - there will always be at 
	 *	least one lobby for each room.
	 *	
	 *	@return			list of lobbies as a vector
	 *	@since			1.0
	 */
	public Vector getLobbies() {}
	/**
	 *	Returns the number of lobbies in this room.  There should always be
	 *	at least one.
	 *	
	 *	@return			size of lobbies list
	 *	@since			1.0
	 */
	public int size() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
