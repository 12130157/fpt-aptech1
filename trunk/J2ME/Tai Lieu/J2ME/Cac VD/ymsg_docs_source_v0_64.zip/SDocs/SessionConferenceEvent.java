package ymsg.network.event;

import ymsg.network.YahooConference;
import ymsg.network.YahooUser;

/**
 *	Represents a conference event.
 *	<p>
 *	<table border="2">
 *	<tr><td>&nbsp</td>
 *		<td><b>getFrom</b></td>
 *		<td><b>getTo</b></td>
 *		<td><b>getMessage</b></td>
 *		<td><b>getRoom</b></td>
 *		<td><b>getUsers</b></td>
*		<td><b>getUser</b></td>
 *	</tr>
 *	<tr><td><i>conferenceInviteReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y (topic)</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n</td>
 *	</tr>
 *	<tr><td><i>conferenceLogonReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	<tr><td><i>conferenceLogoffReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n</td>
 * 		<td>y</td>
 * 		<td>n</td>
 * 		<td>y</td>
 *	</tr>
 *	<tr><td><i><conferenceMessageReceived/i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n</td>
 * 		<td>y</td>
 *	</tr>
 *	</table>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SessionConferenceEvent extends SessionEvent
{	/**
	 *	Create a new instance.  API users should not call this directly.
	 *	The API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param t		target
	 *	@param m		topic/message
	 *	@param r		conference object
	 *	@since			1.0
	 */
	public SessionConferenceEvent(Object o,String t,String f,String m,YahooConference r) {}

	/**
	 *	Create a new instance.  API users should not call this directly.
	 *	The API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param t		target
	 *	@param m		topic/message
	 *	@param r		conference object
	 *	@param u		array of user objects
	 *	@since			1.0
	 */
	 public SessionConferenceEvent(Object o,String t,String f,String m,YahooConference r,YahooUser[] u) {}

	/**
	 *	Returns the conference name (room).  This name is used to identify
	 *	the conference by the API.  It is always a good idea to fetch and
	 *	store this value for later use with <code>Session</code> class
	 *	methods which facilitate conference use.
	 *
	 *	@return			conference object
	 *	@since			1.0
	 */
	public YahooConference getRoom() {}

	/**
	 *	Returns an array of user objects for the other users in this conference.
	 *
	 *	@return			array of Yahoo user objects
	 *	@since			1.0
	 */
	public YahooUser[] getUsers() {}

	/**
	 *	Returns the subject user object for conference events with only one user.
	 *
	 *	@return			array of Yahoo user objects
	 *	@since			1.0
	 */
	public YahooUser getUser() {}

	/**
	 *	Returns the welcome message sent round to introduce this conference.
	 *	This method is a wrapper around <code>getMessage</code> from the
	 *	parent class.
	 *	<p>
	 *	<i>Note: documentation calls this a welcome message, but YIM itself
	 *	displays the text under the heading "Topic".  For this reason this
	 *	API allows either <code>getMessage</code> or <code>getTopic</code>
	 *	to be used.
	 *
	 *	@return			topic/welcome message
	 *	@since			1.0
	 */
	public String getTopic() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
