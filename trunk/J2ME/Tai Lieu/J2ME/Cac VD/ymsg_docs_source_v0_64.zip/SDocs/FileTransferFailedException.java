package ymsg.network;

/**
 *	Thrown when file transfer upload or download fails.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class FileTransferFailedException extends java.lang.RuntimeException
{	FileTransferFailedException(String m) {}
}
