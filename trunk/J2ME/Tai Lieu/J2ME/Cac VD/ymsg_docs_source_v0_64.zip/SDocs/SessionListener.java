package ymsg.network.event;

/**
 *	This interface defines the callbacks necessary for the jYMSG API to
 *	communitcate with the client employing it.  Most of these method will
 *	be called as a direct result of 'packets' arriving from the Yahoo server
 *	to the client.  Note: this API provides an abstract layer of Yahoo's
 *	IM protocol - the methods here to do not necessarily map directly to
 *	specific 'packet' types.
 *	<p>
 *	Because of the baffling array of different types of data which can be
 *	received, the API employs a basic event class, <code>SessionEvent</code> 
 *	for many events types, but specific subclasses when particular fields 
 *	need to be added.  The fields which are 'active' (not null) for any
 *	given event are listed, by way of their accessor methods.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public interface SessionListener
{	/**
	 *	This will be called when the API becomes aware that someone is 
	 *	attempting to send us a file.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getLocation</code> - returns the URL of the file
	 *	<li><code>getTimestamp</code> - returns when the file was sent
	 *	<li><code>getMessage</code> - returns the accompanying message
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void fileTransferReceived(SessionFileTransferEvent ev);

	/**
	 *	Yahoo connection broken.  This method can be called in four 
	 *	circumstances:
	 *	<ol type="i">
	 *	<li>At some point after we call <code>logout</code> on the session, as
	 *		confirmation that the session is now dead.
	 *	<li>At some point before or after <code>login</code> returns, when there
	 *		has been a problem logging in (for example, incorrect password).
	 *	<li>When network problems mean the connection to Yahoo servers is lost.
	 *	<li>When Yahoo wishes to throw us off of the system for any reason (for
	 *		example another client attempts to log in with the same Yahoo id - 
	 *		the original client is terminated.)
	 *	</ol>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void connectionClosed(SessionEvent ev);

	/**
	 *	The complete groups/friends list update has been received.  This 
	 *	typically is generated sometime after <code>refreshFriends</code> 
	 *	has been called on the <code>Session</code> object.  Note: the list 
	 *	is also received as part of the login process, but this API 
	 *	supresses that event if it occures before <code>login</code> has
	 *	finished (which it always does!)
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void listReceived(SessionEvent ev);

	/**
	 *	Someone has sent us an instant messenger (personal) message.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getMessage</code> - returns the accompanying message (Utf8)
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void messageReceived(SessionEvent ev);

	/**
	 *	Someone has sent us a buzz message.  The official Yahoo client prints a 
	 *	'buzz' type message and jiggles the client IM window for a short time 
	 *	to simulate vibrations.  You, however, may choose to handle such messages 
	 *	differently.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getMessage</code> - returns the accompanying message - 'BUZZ!' (Utf8)
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void buzzReceived(SessionEvent ev);

	/**
	 *	Yahoo tells us about a message sent while we were away.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getMessage</code> - returns the accompanying message (Utf8)
	 *	<li><code>getTimestamp</code> - returns when the file was sent
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void offlineMessageReceived(SessionEvent ev);
	
	/**
	 *	A protocol level error occured.  Typically Yahoo is flagging an error 
	 *	in a recent operation.
	 *	<ul>
	 *	<li><code>getMessage</code> - returns the accompanying message, or null (Utf8)
	 *	<li><code>getService</code> - returns the packet service id, see 
	 *		<code>ServiceConstants</code>
	 *	<li><code>getCode</code> - returns a chat error code (purpose unknown) or -1;
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void errorMessageReceived(SessionErrorEvent ev);

	/**
	 *	An internal API exception occured on the input thread.  The input thread
	 *	runs in parallel with the main application.  If it throws an exception
	 *	there is no direct way to report this to the application layer - this
	 *	event provides a mechanism for reporting such exceptions.  (Under 
	 *	normal circumstances the input thread should never throw exceptions, but
	 *	just in case...)
	 *	<ul>
	 *	<li><code>getException</code> - returns the exception object
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void inputExceptionThrown(SessionExceptionEvent ev);
	
	/**
	 *	Yahoo tells us we have unread Yahoo mail.  Note: this informs us of
	 *	the number of unread e-mails, but documentation suggests that it
	 *	may alternatively contain the details of an e-mail itself.
	 *	<ul>
	 *	<li><code>getMail</code> - returns the number of unread mail
	 *	<li><code>getFrom</code> - returns this mail's <i>From</i> field [*]
	 *	<li><code>getMessage</code> - returns this mail's message text [*]
	 *	<li><code>getSubject</code> - returns this mail's <i>subject</i> field [*]
	 *	</ul>
	 *	<i>[*] = These fields are set only if the count, <code>getMail</code>
	 *	is zero.</i>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void newMailReceived(SessionNewMailEvent ev);

	/**
	 *	Yahoo server wants to notify us of something.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getMode</code> - returns whether this is an on or off notification
	 *	<li><code>getService</code> - returns the type of notification (ie: TYPING, GAME)
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void notifyReceived(SessionNotifyEvent ev);

	/**
	 *	Someone wants to add us to their friends list.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id (them!)
	 *	<li><code>getMessage</code> - returns the accompanying message
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void contactRequestReceived(SessionEvent ev);

	/**
	 *	Someone has rejected our attempts to add them to our friends list.
	 *	<ul>
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getMessage</code> - returns the accompanying message
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void contactRejectionReceived(SessionEvent ev);
		
	/**
	 *	Someone is inviting us to join a conference.  Use the 
	 *	<code>Session</code> methods, <code>acceptConferenceInvite</code> 
	 *	to accept or <code>declineSessionInvite</code> to decline. 
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getTopic</code> - returns the intive message (see message)
	 *	<li><code>getMessage</code> - returns the intive message (see topic)
	 *	<li><code>getRoom</code> - returns the conference name
	 *	<li><code>getUsers</code> - returns the id's of users invited
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void conferenceInviteReceived(SessionConferenceEvent ev);
	
	/**
	 *	Someone has declined an invite to join our conference.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getRoom</code> - returns the conference name
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void conferenceInviteDeclinedReceived(SessionConferenceEvent ev);

	/**
	 *	Someone has joined a conference we are part of.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getRoom</code> - returns the conference name
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void conferenceLogonReceived(SessionConferenceEvent ev);

	/**
	 *	Someone is leaving a conference we are part of.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getRoom</code> - returns the conference name
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void conferenceLogoffReceived(SessionConferenceEvent ev);

	/**
	 *	Someone has sent round a message to the conference members.
	 *	<ul>
	 *	<li><code>getTo</code> - returns the target Yahoo id (us!)
	 *	<li><code>getFrom</code> - returns the sender's Yahoo id
	 *	<li><code>getMessage</code> - returns the message text (Utf8)
	 *	<li><code>getRoom</code> - returns the conference name
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void conferenceMessageReceived(SessionConferenceEvent ev);
	
	/**
	 *	Friend's details have been updated.
	 *	<ul>
	 *	<li><code>getFriends</code> - returns an array of <code>YahooUser</code>
	 *		objects detailing the friend users who have changed. 
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void friendsUpdateReceived(SessionFriendEvent ev);

	/**
	 *	Successfully added a friend.
	 *	<ul>
	 *	<li><code>getFriend</code> - returns the <code>YahooUser</code> object
	 *		of the friend
	 *	<li><code>getGroup</code> - returns the group they were added to
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void friendAddedReceived(SessionFriendEvent ev);

	/**
	 *	Successfully removed a friend.
	 *	<ul>
	 *	<li><code>getFriend</code> - returns the <code>YahooUser</code> object
	 *		of the friend
	 *	<li><code>getGroup</code> - returns the group they were removed from
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void friendRemovedReceived(SessionFriendEvent ev);

	/**
	 *	Someone has joined the chatroom lobby we are currently connected to.
	 *	Note: the protocol supports more than one user listed in a single chat 
	 *	packet (and therefore a single event) - but this facility <b>appears</b>
	 *	not to be used.
	 *	<ul>
	 *	<li><code>getChatuser/s</code> - the user (or list of users) who joined.
	 *	<li><code>getLobby</code> - the chat lobby they joined.
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void chatLogonReceived(SessionChatEvent ev);

	/**
	 *	Someone has left the chatroom lobby we are currently connected to.
	 *	Note: the protocol supports more than one user listed in a single chat 
	 *	packet (and therefore a single event) - but this facility <b>appears</b>
	 *	not to be used.  Also: beware - it appears possible to <i>very 
	 *	occassionally</i> receive logoff packets for users we were never told 
	 *	about in the first place!  Perhaps they joined simultaneously with us, 
	 *	and were never included in the initial list of users, or subsequent 
	 *	updates?  (Or maybe Yahoo's chat server is buggy!?!!)
	 *	<ul>
	 *	<li><code>getChatUser/s</code> - the user (or list of users) who joined.
	 *	<li><code>getLobby</code> - the chat lobby they joined.
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void chatLogoffReceived(SessionChatEvent ev);

	/**
	 *	Someone has sent a message to the chatroom lobby we are currently 
	 *	connected to.
	 *	Note: the protocol supports more than one user listed in a single chat 
	 *	packet (and therefore a single event) - but this facility <b>appears</b>
	 *	not to be used.  Also: it may be possible to receive messages from users
	 *	we were never told about - see <code>chatLogoffReceived</code> above.
	 *	<ul>
	 *	<li><code>getChatuser(s)</code> - the user (or list of users) who joined.
	 *	<li><code>getLobby</code> - the chat lobby they joined.
	 *	<li><code>getMessage</code> - returns the accompanying message
	 *	</ul>
	 *	Note: this method will also be called if a packet of code 0x20 is
	 *	received (an old-style YCHT personal message packet?).
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void chatMessageReceived(SessionChatEvent ev);

	/**
	 *	An update to a chat user's details has been received.
	 *	<ul>
	 *	<li><code>getChatUser</code> - the updated user.
	 *	<li><code>getLobby</code> - the chat lobby they're in.
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void chatUserUpdateReceived(SessionChatEvent ev);

	/**
	 *	The connection to a chat lobby has been lost.  For example, if the
	 *	chat system timed us out after a period of inactivity.
	 *	<ul>
	 *	<li><code>getLobby</code> - the chat lobby just departed.
	 *	</ul>
	 *
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void chatConnectionClosed(SessionEvent ev);
	
	/**
	 *	A chat captcha has been requested.
	 *	<ul>
	 *	<li><code>getCaptchaMessage()</code> - the full message.
	 *	<li><code>getCaptchaURL()</code> - the URL portion of the message.
	 *	<li><code>getLobby</code> - the chat lobby they're in.
	 *	</ul>
	 *	
	 *	@param ev		The event object
	 *	@since 			1.0
	 */
	public void chatCaptchaReceived(SessionChatEvent ev);


}
