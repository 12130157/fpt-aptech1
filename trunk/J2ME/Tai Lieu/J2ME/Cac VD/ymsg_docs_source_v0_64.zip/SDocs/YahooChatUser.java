package ymsg.network;

/**
 *	Wraps a regular user object to provide the extra information provided by 
 *	a chat user.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class YahooChatUser
{	/**
	 *	Returns the underlying user object.
	 *
	 *	@return			Yahoo user object
	 *	@since			1.0
	 */
	public YahooUser getUser() {}
	/**
	 *	Returns the user's Yahoo id.  A shortcut for 
	 *	<code>getUser().getId()</code> .
	 *
	 *	@return			Yahoo ID of user
	 *	@since			1.0
	 */
	public String getId() {}
	/**
	 *	Returns the age of the user, or zero if not given.
	 *
	 *	@return			user's age
	 *	@since			1.0
	 */
	public int getAge() {}
	/**
	 *	Returns the alias of this user in the current chatroom, or null if no
	 *	alias.
	 *
	 *	@return			user's chat alias, or null
	 *	@since			1.0
	 */
	public String getAlias() {}
	/**
	 *	Returns the location of this user, or null if not specified.
	 *
	 *	@return			location string, or null
	 *	@since			1.0
	 */
	public String getLocation() {}
	/**
	 *	Returns true if this user's profile shows them as male.  (False does
	 *	<u>not</u> mean they are female!)
	 *
	 *	@return			true if male
	 *	@since			1.0
	 */
	public boolean isMale() {}
	/**
	 *	Returns true if this user's profile shows them as female.  (False does
	 *	<u>not</u> mean they are male!)
	 *
	 *	@return			true if female
	 *	@since			1.0
	 */
	public boolean isFemale() {}
	/**
	 *	Returns true if this user has an accessible webcam.
	 *
	 *	@return			true if webcam available.
	 *	@since			1.0
	 */
	public boolean hasWebcam() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
