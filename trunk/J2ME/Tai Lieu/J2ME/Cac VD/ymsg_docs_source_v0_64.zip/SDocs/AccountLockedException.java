package ymsg.network;

import java.net.URL;

/**
 *	Thrown when logging in, to indicate the account has been locked out.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class AccountLockedException extends YahooException
{	AccountLockedException(String m,URL u){}

	/**
	 *	Yahoo often provides a URL to jump to for account problems.
	 *	Typically it is a login page, where more verbose error messages
	 *	can be obtained.
	 *
	 *	@return			URL of help page, or null
	 *	@since			1.0
	 */
	public URL getWebPage() {}
}
