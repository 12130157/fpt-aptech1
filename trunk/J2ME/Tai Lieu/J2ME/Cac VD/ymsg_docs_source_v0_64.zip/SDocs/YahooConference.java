package ymsg.network;

import java.util.Vector;

/**
 *	Represents an instant messaging conference.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class YahooConference
{	/**
	 *	Returns the unique string identifier for this conference room.  This is
	 *	an implementation detail, and would not normally be used by API users.
	 *
 	 *	@return			name of conference
	 *	@since			1.0
	 */
	public String getName() {}
	/**
	 *	Returns true if the conference is closed.
	 *
 	 *	@return			true if conference closed.
	 *	@since			1.0
	 */
	public boolean isClosed() { return closed; }
	/**
	 *	Returns the list of users who are currently in the conference.  The
	 *	returned <code>Vector</code> contains <code>YahooUser</code> objects
	 *	for each user.
	 *	<p>
	 *	<i>Note: this method clones the members list, and as such should be
	 *	considered expensive.</i>
	 *
 	 *	@return			name of conference
	 *	@since			1.0
	 */
	public Vector getMembers() { return (Vector)users.clone(); }
	/**
	 *	Returns the identity used to create this conference.  All messages
	 *	will be badged as this identity.
	 *
 	 *	@return			the identity used in this conference
	 *	@since			1.0
	 */
	public YahooIdentity getIdentity() { return identity; }


	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
