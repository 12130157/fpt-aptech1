package ymsg.support;

import java.lang.ref.*;
import java.util.*;
import javax.swing.ListModel;
import javax.swing.event.*;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import ymsg.network.*;
import ymsg.network.event.*;

/**
 *	A handy class for creating self-updating models for use with Swing's MVC 
 *	scheme.
 *	<p>
 *	This class is rather clever.  It will register itself with the session
 *	provided, and enacts any events from said session on the model objects
 *	it creates automatically.  Eg, having created a ListModel for a chat
 *	room, this class will automatically update the ListModel's status, based
 *	upon messages received from Yahoo (or rather, the session events they
 *	generate).
 *	<p>
 *	The result is that users coming and going, or changing their status, will
 *	be automatically reflected by the model, and any Swing component 'listening'
 *	will be told to update its display.  (For best results, take advantage of
 *	Swing's 'cell renderer' scheme to include status icons etc, based upon data
 *	provided by these models.) 
 *	<p>
 *	<i>Note: you should not create duplicate models for the same data, as
 *	subsequent calls will create models which superceed previous models.
 *	Each source of data, be it the user's groups, or a chat room, should have 
 *	only one model created for it, which should then be passed to all Swing
 *	components which need to use that model.  (This is how MVC is supposed
 *	to work anyway - with single models for each distinct data source.)</i>
 *	<p>
 *	<i>Technical note: this class uses weak references to map the objects
 *	it creates.  The models are automatically freed for garbage collection 
 *	once there are no strong references left outside the factory instance.</i>
 *	<p>
 *	<font color="Red">This is an experimental class, with only basic testing
 *	applied.  Please report all bugs via the usual channels.</font>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SwingModelFactory extends SessionAdapter
{	/**
	 *	Create a model factory.  All models will be based upon the session
	 *	object provided.
	 *	<p>
	 *	<i>Note: this method will attempt to register listeners with the given
	 *	session.</i>
	 *
	 *	@param ss		session
	 *	@since			1.0
	 */
	public SwingModelFactory(Session ss) {}

	/**
	 *	Create a Swing ListModel, based upon the activities of the users in a
	 *	given chatroom lobby.
	 *	<p>
	 *	<i>Note: please only create one model per lobby.  Future implementations
	 *	of this method may refuse to work a second time for a given lobby.</i>.
	 *
	 *	@param ycl		the lobby to model
	 *	@param sort		true if the list is to be kept sorted
	 *	@return			Swing ListModel
	 *	@since			1.0
	 */
	public ListModel createListModel(YahooChatLobby ycl,boolean sort) {}
	/**
	 *	Create a Swing ListModel, based upon the activities of the users in a
	 *	given conference.
	 *	<p>
	 *	<i>Note: please only create one model per conference.  Future
	 *	implementations of this method may refuse to work a second time for a
	 *	given conference.</i>.
	 *	<p>
	 *	<i>Note: this model is, as yet, not fully implemented/tested.</i>
	 *
	 *	@param yc		the conference to model
	 *	@param sort		true if the list is to be kept sorted
	 *	@return			Swing ListModel
	 *	@since			1.0
	 */
	public ListModel createListModel(YahooConference yc,boolean sort) {}
	/**
	 *	Create a Swing TreeModel, based upon the activities of the users in
	 *	the session's friends groups.
	 *	<p>
	 *	<i>Note: please only create model per session.  Future implementations 
	 *	of this method may refuse to work a second time.</i>.
	 *
	 *	@param sort		true if the list is to be kept sorted
	 *	@return			Swing TreeModel
	 *	@since			1.0
	 */
	public TreeModel createTreeModel(boolean sort) {}

	/**
	 *	Convenience method to create an empty list model.  Useful for blanking
	 *	a Swing JList in between leaving one chatroom and joining another.
	 *	(Swing doesn't seem to provide a way to 'unset' a model once one has
	 *	been set, to get the JList to return to a default empty list!)
	 *
	 *	@return			Swing ListModel
	 *	@since			1.0
	 */
	public static ListModel getEmptyListModel() {}
}
