package ymsg.network.event;

import ymsg.network.YahooChatUser;
import ymsg.network.YahooChatLobby;

/**
 *	Represents a chatroom event.
 *	<p>
 *	<table border="2">
 *	<tr><td>&nbsp</td>
 *		<td><b>getFrom</b></td>
 *		<td><b>getChatUser</b></td>
 *		<td><b>getChatUsers</b></td>
 *		<td><b>getLobby</b></td>
 *		<td><b>getMessage</b></td>
 *	</tr>
 *	<tr><td><i>chatLogonReceived</i></td>
 * 		<td>y<sup>[1]</sup></td>
 * 		<td>y<sup>[1]</sup></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n</td>
 *	</tr>
 *	<tr><td><i>chatLogoffReceived</i></td>
 * 		<td>y<sup>[1]</sup></td>
 * 		<td>y<sup>[1]</sup></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n</td>
 *	</tr>
 *	<tr><td><i>chatMessageReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y<sup>[2]</sup></td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	</table>
 *	<p>
 *	The protocol supports the ability to deliver multiple users in each
 *	chat packet, but an examination of actual chat packets reveals this
 *	feature appears not to be used.  So with that in mind...<br>
 *	[1] = to be super-safe it is best to use the array version of this
 *	get method, and not to assume there will be only one user.<br>
 *	[2] = there is no way a single message can come from multiple users,
 *	so it is safe to use the single user get method if you want.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SessionChatEvent extends SessionEvent
{	/**
	 *	Create a new instance.  API users should not call this directly.
	 *	The API itself will create its own events.  This constructor is
	 *	for logon/off events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param sz		number of users in event
	 *	@param ycl		lobby object for this event
	 *	@since			1.0
	 */
	public SessionChatEvent(Object o,int sz,YahooChatLobby ycl) {}
	/**
	 *	Create a new instance.  API users should not call this directly.
	 *	The API itself will create its own events.  This constructor is
	 *	used for message events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param ycu		the chat user object for this event
	 *	@param m		message text (UTF-8)
	 *	@param ycl		lobby object for this event
	 *	@since			1.0
	 */
	public SessionChatEvent(Object o,YahooChatUser ycu,String m,YahooChatLobby ycl) {}

	/**
	 *	Returns a single chat user (actually just the first user in the
	 *	array of users specified) relating to this event.  This method
	 *	is suitable for message receiving events.
	 *
	 *	@return			a chat user object
	 *	@since			1.0
	 */
	public YahooChatUser getChatUser() {}
	/**
	 *	Returns an array of chat users relating to this event.  This
	 *	method is suitable for chat logon/off events.
	 *
	 *	@return			an array of chat user object
	 *	@since			1.0
	 */
	public YahooChatUser[] getChatUsers() {}
	/**
	 *	Returns the chat lobby relating to this event.
	 *
	 *	@return			a chat lobby object
	 *	@since			1.0
	 */
	public YahooChatLobby getLobby() {}
	/**
	 *	Returns the id of a single chat user relating to this event.  Just
	 *	a shortcut to <code>getUser().getId()</code>.  This method is
	 *	suitable for message receiving events.
	 *
	 *	@return			Yahoo id as a string
	 *	@since			1.0
	 */
	public String getFrom() {}
	/**
	 *	Returns true if this message is an emote.
	 *
	 *	@return			True if emote
	 *	@since			1.0
	 */
	public boolean isEmote() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
