package ymsg.network;

import java.util.*;

/**
 *	Represents a single chat lobby.  Yahoo chatrooms consist of one or more 
 *	numbered lobbies inside each public/private room.  The name of room and the 
 *	number of the lobby (separated by a colon) form the 'network name' of the 
 *	lobby - used by Yahoo to identify uniquely a given chat 'space' on its 
 *	systems.  Each lobby has a count of users, a count of voice chat users, and 
 *	a count of webcam users.  These counts are populated by the methods which 
 *	load category and room structures in <code>YahooChatCategory</code> - they 
 *	<b>are not</b> updated after initially created.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class YahooChatLobby
{	/**
	 *	Returns the lobby number.  This number, together with the parent chatroom
	 *	name, form the unique 'network name' which identifies this chat space.
	 *
 	 *	@return			lobby number
	 *	@since			1.0
	 */
	public int getLobbyNumber() {}
	/**
	 *	Returns the initial user count.  The current version of the jYMSG API 
	 *	does not update this automatically, once a room is entered.
 	 *
	 *	@return			chat user count
	 *	@since			1.0
	 */
	public int getUserCount() {}
	/**
	 *	Returns the initial voice user count.  The current version of the jYMSG 
	 *	API does not update this automatically, once a room is entered.
 	 *
	 *	@return			chat user count
	 *	@since			1.0
	 */
	public int getVoiceCount() {}
	/**
	 *	Returns the initial webcam user count.  The current version of the jYMSG 
	 *	API does not update this automatically, once a room is entered.
 	 *
	 *	@return			chat user count
	 *	@since			1.0
	 */
	public int getWebcamCount() {}
	/**
	 *	Returns the unique network name of this lobby.  This is formed by 
	 *	adding the lobby number to the end of the parent room's name, separated
	 *	by a colon.  This data is implementation detail, and will usually not
	 *	be needed by API users.
 	 *
	 *	@return			network name of lobby.
	 *	@since			1.0
	 */
	public String getNetworkName() { return netName; }
	/**
	 *	Returns the parent chatroom object.
 	 *
	 *	@return			chatroom object
	 *	@since			1.0
	 */
	public YahooChatRoom getParent() { return parent; }
	/**
	 *	Returns a list of all current members of this chatroom lobby.  Yahoo
	 *	doesn't deliver this data as part of its chat rooms directory.  The
	 *	list of members in a room is not delivered until a session actually
	 *	logs into a lobby, and will only be current for the duration of the
	 *	session's stay in the lobby.
	 *	<p>
	 *	<i>Note: this method constructs the list from the lobby's own internal 
	 *	hashtable, and as such must be considered expensive.</i>
	 *	
	 *	@return			hashtable:  key=id,  value=YahooUser object
	 *	@since			1.0
	 */
	public Vector getMembers() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
