package ymsg.network.event;

/**
 *	Encapsulates a high level error.  These are errors reported or caused by
 *	Yahoo itself, or this API - not low level problems like network faults.
 *	<p>
 *	To get the error message, use <code>getMessage</code> from the parent
 *	class.
 *	<p>
 *	The service ID can be useful in determining what kind of error this might
 *	be.  For example, a SERVICE_CONTACTIGNORE error is usually something along
 *	the lines of ignoring a user who is already ignored, or attempting to
 *	ignore someone on your friends list.  These are non-fatal, an can be safely
 *	ignored (pun not intended) - although a client may wish to report them to
 *	the user.
 *	<p>
 *	<table border="2">
 *	<tr><td>&nbsp</td>
 *		<td><b>getMessage</b></td>
 *		<td><b>getService</b></td>
 *		<td><b>getCode</b></td>
 *	</tr>
 *	<tr><td><i>errorPacketReceived</i></td>
 * 		<td>y or null</td>
 * 		<td>y</td>
 * 		<td>y or -1<sup>[1]</sup></td>
 *	</tr>
 *	<p>
 *	[1] = this code only used in chat error packets, it seems - meaning
 *	unknown!
 *	</table>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SessionErrorEvent extends SessionEvent
{	public SessionErrorEvent(Object o,String m,int sv) {}

	/**
	 *	Returns the service id of the packet which caused the error.  See
	 *	the interface <code>ServiceConstants</code>.
	 *
	 *	@return			servide id number
	 *	@since			1.0
	 */
	public int getService() {}

	/**
	 *	Returns the error code, as detailed by Yahoo chatrooms.  The
	 *	meaning of this code is unknown.
	 *
	 *	@return			servide id number
	 *	@since			1.0
	 */
	public int getCode() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 *	@since			1.0
	 */
	public String toString() {}
}
