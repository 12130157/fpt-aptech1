package ymsg.support;

import java.util.Hashtable;

/**
 *	Provides basic anti-spam functionality for chatrooms.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class AntiSpam
{	/**
	 *	Message is repeat of recent message.
	 *
	 *	@since			1.0
	 */
	public static final int REPEAT			=	0x0001;
	/**
	 *	Message is attempt to flood chatroom.  (Currently unsupported.)
	 *
	 *	@since			1.0
	 */
	public static final int FLOOD			=	0x0002;
	/**
	 *	Message is overwhelmingly upper case letters.
	 *
	 *	@since			1.0
	 */
	public static final int CAPS			=	0x0004;


	/**
	 *	Construct a new anti-spam instance.
	 *
	 *	@since			1.0
	 */
	public AntiSpam() {}	

	/**
	 *	Returns an integer of flags denoting which checks failed.  The static
	 *	constants elsewhere in this class should be masked against this value
	 *	to determine whether a particular anti-spam test was 'alerted' by the
	 *	message provided.
	 *	<p>
	 *	<i>Note: this method will extracted the plain text from a Yahoo richly
	 *	formatted message automatically.  There is no need to do this yourself.</i>
	 *
	 *	@param u		id of user who sent the message
	 *	@param m		text of message (can be formatted)
	 *	@return			int of flags
	 *	@since			1.0
	 */
	public int getViolations(String u,String m) {}
}
