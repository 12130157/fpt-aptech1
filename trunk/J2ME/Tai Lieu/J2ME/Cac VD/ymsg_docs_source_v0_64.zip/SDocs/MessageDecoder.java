package ymsg.support;

import javax.swing.*;
import javax.swing.text.Document;
import java.util.Stack;

/**
 *	This message decoder class is designed to work along side the main
 *	jYMSG classes, accepting raw message strings from Yahoo, and translating
 *	them into something a bit more Java-friendly.
 *	<p>
 *	Currently the decoder can translate messages into basic HTML and plain
 *  text (formatting stripped).  It can also append styled text onto the end
 *	of a Swing Document object, complete with smiley icons if desired.
 *	<p>
 *	<font color="Red">Please note: this class is new and experimental.</font>
 *	<pre>
 *	String a[] =
 *	{   "&#92;u001b[#000000m&lt;font face=\"Verdana\" size=\"10\"&gt;No, and it's not that common anyway now, Facs.",
 *	    "&#92;u001b[31m&lt;font face=\"Verdana\" size=\"13\"&gt;can any1 help me?",
 *	    "&#92;u001b[31mRFred, I got it, hold on.",
 *	    "&lt;FADE #00002b,#4848ff,#4848ff,#00002b,#4848ff,#4848ff&gt;&lt;font face=\"Comic Sans MS\" size=\"16\"&gt;any programmerz who make yahoo programz:-?&lt;/FADE&gt;",
 *	    "&#92;u001b[30m&lt;font face=\"times\" size=\"14\"&gt;&#92;u001b[1m&#92;u001b[2manyone here using gyach enhanced?",
 *	    "can you make such a monster?",
 *	    "&lt;font face=\"Arial\" size=\"10\"&gt;&#92;u001b[#000000m&lt;FADE #000000,#FF0000,#000000&gt;whassup mah fellow programma's?!&lt;/FADE&gt;&lt;font YmLite 41&gt;",
 *	    "&lt;font face=\"Symbol\" size=\"12\"&gt;&#92;u001b[#a0a0ffm&#92;u001b[1m&#92;u001b[4m$&#92;u001b[x1m&#92;u001b[x4m&lt;/font&gt;&lt;/font&gt;&lt;font face=\"Arial\" size=\"10\"&gt; &#92;u001b[#000000m.9 times 10 &lt;&gt; 9.9&lt;/font&gt;&lt;font YHLT ~&gt;&lt;/font&gt;",
 *	    "Happy :-) :)  Sad :(  Wink ;)  Grin :D  Eyes ;;) Confused :/  Love :X  Blush :\"&gt; Tongue :p Kiss :*",
 *	    "Shock :O  Anger X-(  Smug :&gt;  Cool B)  Worried :s  Devil &gt;:)  Cry :((  Laugh :))  Straight :|  Eyebrow /:)",
 *	    "Angel O:)  Nerd :-B  Hand =;  Sleep I-)  Rolling 8-|  Sick :-&  Shhh :-$  Not talk [-(  Clown :o)  Silly 8-}",
 *	    "Tired (:|  Drool =P~  Think :-?  D'oh #-o  Applause =D&gt;"
 *	};
 *	// Build window
 *	JFrame frame = new JFrame();
 *	JTextPane tp = new JTextPane();
 *	tp.setEditable(false);
 *	frame.getContentPane().add(tp);  frame.setSize(400,350);
 *	frame.setVisible(true);
 *	// Get the document
 *	Document doc = tp.getDocument();
 *	// Decode the message content.  Note: because we are making several
 *	// versions of the same message, we've taken a multi-step process,
 *	// although this class has static methods to do an all-in-one conversion.
 *	for(int i=0;i&lt;a.length;i++)
 *	{   // Create decoder, and set the emoticon (smiley) option on
 *	    MessageDecoderSettings mds = new MessageDecoderSettings();
 *	    mds.setEmoticonsDecoded(true);
 *	    MessageDecoder md = new MessageDecoder(mds);
 *	    // Decode the message into an element tree, returns root node.
 *	    // Note: we don't actually have to create a brand new MessageDecoder
 *	    // object for each decode - we could just re-use an existing one.
 *	    MessageElement sc=md.decode(a[i]);
 *	    // Dump to stdout the HTML and plain text versions
 *	    System.out.println(sc.toHTML());
 *	    System.out.println(sc.toText());
 *	    // Append to the message to Swing Document
 *	    sc.appendToDocument(doc);
 *	}
 *	</pre>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class MessageDecoder
{	/**
	 *	Create a new instance of a decoder.
	 *	<p>
	 *	<i>Note: it is actually possible to re-use decoder objects for
	 *	multiple decodes, even across different threads.</i>
	 *
	 *	@since			1.0
	 */
	public MessageDecoder() {}

	/**
	 *	Create a new instance of a decoder, using settings.  The settings
	 *	object will be defered to for key aspects of the decoding process.
	 *	See <code>MessageDecoderSettings</code> for details.
	 *	<p>
	 *	<i>Note: it is actually possible to re-use decoder objects for
	 *	multiple decodes, even across different threads.</i>
	 *
	 *	@param md		decoders settings
	 *	@since			1.0
	 */
	public MessageDecoder(MessageDecoderSettings md) {}

	/**
	 *	Provide a settings object for this decoder to work with.
	 *
	 *	@param md		decoders settings
	 *	@since			1.0
	 */
	public void setDecoderSettings(MessageDecoderSettings md) {}
	/**
	 *	Return the current settings object used by this decoder, if set.
	 *
	 *	@return			settings, or null
	 *	@since			1.0
	 */
	public MessageDecoderSettings getDecoderSettings() {}


	/**
	 *	Decodes a Yahoo message to an element tree.  Returns the topmost
	 *	(root) node of the message tree.
	 *	<p>
	 *	<i>Note: it is actually possible to re-use decoder objects for
	 *	multiple decodes, even across different threads.</i>
	 *
	 *	@param m		Yahoo message text, possibly containing Utf8.
	 *	@return			root element object
	 *	@since			1.0
	 */
	public synchronized MessageElement decode(String m) {}

	/**
	 *	Convenience method to convert Yahoo message to HTML.  This method
	 *	creates a <code>MessageDecoder</code>, decodes the message and returns
	 *	the output from the appropriate translator method, all in one.
	 *
	 *	@param m		Yahoo message text, possibly containing Utf8.
	 *	@return			HTML fragment string
	 *	@since			1.0
	 */
	public String decodeToHTML(String m) {}
	/**
	 *	Convenience method to convert Yahoo message to plain text.  This method
	 *	creates a <code>MessageDecoder</code>, decodes the message and returns
	 *	the output from the appropriate translator method, all in one.
	 *
	 *	@param m		Yahoo message text, possibly containing Utf8.
	 *	@return			unstyled string
	 *	@since			1.0
	 */
	public String decodeToText(String m) {}
	/**
	 *	Convenience method to convert Yahoo message to styled Swing text.  This
	 *	method creates a <code>MessageDecoder</code>, decodes the message and
	 *	appends the output from the appropriate translator method to the
	 *	provided <code>Swing Document</code> object, all in one.
	 *
	 *	@param m		Yahoo message text, possibly containing Utf8.
	 *	@param doc		Swing Document object
	 *	@since			1.0
	 */
	public void appendToDocument(String m,Document doc) {}
}
