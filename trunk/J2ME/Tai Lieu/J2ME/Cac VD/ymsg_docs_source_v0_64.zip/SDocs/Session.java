package ymsg.network;

import ymsg.network.event.*;
import java.awt.Component;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;
import java.net.*;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/**
 *	Encapsulates one instant message session, using YMSG.  When writing a
 *	client, this is the entry point into the API, allowing access to YMSG
 *	features and generating events based upon incoming network activity.
 *	<p>
 *	This document uses various terms
 *	<table border="2" align="center">
 *		<tr>
 *			<td align="Center"><b>Term</b></td>
 *			<td align="Center"><b>Meaning</b></td>
 *		</tr>
 *		<tr><td>User</td><td>A single unique Yahoo user</td></tr>
 *		<tr><td>Friend</td><td>A user who is in your Yahoo friends list</td></tr>
 *		<tr><td>Group</td><td>One sub-division of your Yahoo friends list</td></tr>
 *		<tr><td>Contact</td><td>A Yahoo user (not necessarily a friend) who has
 * 				contacted you</td></tr>
 *		<tr><td>Packet</td><td>A single Yahoo network message</td>
 *		<tr><td>YMSG</td><td>Yahoo Instant Messager protocol</td>
 *		</tr>
 *	</table>
 *	<p>
 *	The connection handling and general housekeeping methods are:
 *	<ul>
 *	<li>public void login(String u,String p)
 *	<li>public void logout()
 *	<li>public void reset()
 *	<li>public int getSessionStatus() {}
 *	</ul>
 *	The Yahoo status methods are used to change the way your client is
 *	repesented to the rest of the YMSG world - normally they are used
 *	to indicate whether you are busy, out of the office, etc.  The
 *	status methods are:
 *	<ul>
 *	<li>public long getStatus() {}
 *	<li>public synchronized void setStatus(long s)
 *	<li>public synchronized void setStatus(String m,boolean b)
 *	</ul>
 *	The users/groups list methods are used to alter the list of 'friend' users
 *	and their associated groups (the folders they occupy in the on-screen
 *	tree).  Users are represented by either an id (text string) or a
 *	<code>YahooUser</code> object.  The latter are canonical, meaning that
 *	only one object is ever created for each user.  If you hold a reference
 *	to a YahooUser object, the values inside it will be updated as the
 *	status of the user changes.  The friends/groups/users methods are:
 *	<ul>
 *	<li>public YahooGroup[] getGroups()
 *	<li>public String[] getIdentities()
 *	<li>public Hashtable getUsers()
 *	<li>public void refreshFriends()
 *	</ul>
 *	Conferences are ad-hoc private chatrooms, with users invited to join by
 *	a host.  The conference methods are:
 *	<ul>
 *	<li>public String createConference(String[] users,String msg)
 *	<li>public void acceptConferenceInvite(String room)
 *	<li>public void declineConferenceInvite(String room,String msg)
 *	<li>public void extendConference(String room,String user,String msg)
 *	<li>public void sendConferenceMessage(String room,String msg)
 *	<li>public void leaveConference(String room)
 *	</ul>
 *	Chatrooms are themed instant messager forums, where like-minded
 *	users can meet and chat.  The chatroom methods are:
 *	<ul>
 *	<li>public void chatLogin(YahooChatLobby ycl)
 *	<li>public void chatLogout()
 *	<li>public void sendChatMessage(String msg)
 *	</ul>
 *	Here's an example of some very basic sample code, connecting to the
 *	server and sending a single message, before disconnecting:
 *	<pre>
 *	try
 *	{   <i>// Create a session, try fallback ports if default fails</i>
 *	    Session ss = new Session();
 *	    <i>// Register for session events</i>
 *	    ss.addSessionListener(new MySessionHandler());
 *	    <i>// Optionally, set status to login as invisible</i>
 *	    ss.setStatus(StatusConstants.STATUS_INVISIBLE);
 *	    <i>// Login (obviously you'd use your real username/password)</i>
 *	    ss.login("username","password");
 *	    <i>// Did we successfully log in?</i>
 *	    if(ss.getSessionStatus()==MESSAGING)
 *	    {   <i>// We might want to save the port somewhere for next login attempt</i>
 *	        System.out.println("Success on port: "+session.getPort());
 *	        <i>// Send a message to myFriend, wait for 5 seconds, then logout</i>
 *	        ss.sendMessage("myFriend","Borag Thung, Earthlet");
 *	        try { Thread.sleep(5*1000); } catch(InterruptedException e) {}
 *	        ss.logout();
 *	    }
 *	    else
 *	    {   <i>// Failed to log in - reset so we can re-use the same object</i>
 *	        ss.reset();
 *	    }
 *	}catch(Exception e) { ss.reset(); }
 *	</pre>
 *	To modify the status there are a couple of overloaded methods.  Here's
 *	some examples of how to use them:
 *	<pre>
 *	<i>// Change to on phone and change to invisible</i>
 *	ss.setStatus(StatusConstants.STATUS_ONPHONE);
 *	ss.setStatus(StatusConstants.STATUS_INVISIBLE);
 *	<p>
 *	<i>// Change to custom away message, and custom back (available) message
 *	// (the API automatically sets the status to custom for us)</i>
 *	ss.setStatus("I'm otta'here!",true);
 *	ss.setStatus("Ready and waiting!!",false);
 *	</pre>
 *	To print the group and friends list, we might do something like this:
 *	<pre>
 *	YahooGroup[] yg = ss.getGroups();
 *	for(int i=0;i&lt;yg.length;i++)
 *	{   System.out.println(yg[i].getName());
 *	    for(int j=0;j&lt;yg[i].size();j++)
 *	    {   YahooUser yu = yg[i].getUserAt(j);
 *	        System.out.println("  "+yu.toString());
 *	    }
 *	}
 *	</pre>
 *	Upon receiving a message we might do something like this (note: see
 *	<code>SessionListener</code> for <code>messageReceived</code> details) :
 *	<pre>
 *	public void messageReceived(SessionEvent ev)
 *	{   String from=ev.getFrom() , msg=ev.getMessage();
 *	    Hashtable h = ss.getUsers();
 *	    YahooUser yu = (YahooUser)h.get(from);
 *	    if(yu==null)
 *	    {   System.out.println("&lt;Not a friend&gt; "+from+": "+msg);
 *	    }
 *	    else
 *	    {   if(yu.isIgnored())  return;
 *	            else  System.out.println(yu.getId()+": "+msg);
 *	    }
 *	}
 *	</pre>
 *	Before we log into a chatroom we need to select one from the list of
 *	room lobbies available at Yahoo.  Rooms are organised into a hierarchy
 *	of categories, each category holding zero or more categories and/or
 *	zero or more public rooms and/or zero or more private rooms.  Each
 *	room holds one or more lobby.
 *	<pre>
 *	<i>// Load first lobby of first room of first category</i>
 *	YahooChatCategory root = YahooChatCategory.loadCategories();
 *	YahooChatCategory ycc = (YahooChatCategory)root.getCategories().elementAt(0);
 *	YahooChatRoom ycr = (YahooChatRoom)ycc.getPublicRooms().elementAt(0);
 *	YahooChatLobby ycl = (YahooChatLobby)ycr.getLobbies().elementAt(0);
 *	</pre>
 *	Having selected a lobby, connecting and using a room is easy.
 *	<pre>
 *	<i>// Connect to a lobby, send a message, then logout</i>
 *	ss.chatLogin(ycl);
 *	ss.sendChatMessage("Hello world!");
 *	ss.chatLogout();
 *	</pre>
 *	Messages from the room arrive as part of methods in the
 *	<code>SessionListener</code> interface.  <code>chatLogonReceived</code>
 *	and <code>chatLogoffReceived</code> inform us of members arriving and
 *	leaving, while <code>chatMessageReceived</code> details a new chat
 *	message.
 *	<p>
 *	Identities are Yahoo's way of allowing users to have multiple aliases,
 *	and this package supports them via the <code>YahooIdentity</code> object.
 *	An array of these objects is created during the login process, accessible
 *	via the <code>getIdentities</code> method.  The objects in this array can
 *	then be passed to various overloaded methods, and the resulting network
 *	messages will be 'badged' with that identity.
 *	<pre>
 *	YahooIdentity[] ids = ss.getIdentities();
 *	ss.sendMessage("lois","This looks like a job for...",ids[0]);
 *	ss.sendMessage("lois","Superman!",ids[1]);
 *	</pre>
 *	In the above example the user <i>lois</i> will be sent a message from two
 *	apparently different users.  Little does she suspect that they are the 
 *	same person.  (In reality you should not 'hard code' identity objects by 
 *	index like this, as objects may be re-ordered each time the data is 
 *	refreshed.)
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class Session implements StatusConstants,ServiceConstants
{	/**
	 *	Creates a single Yahoo session using the best guess connection
	 *	handler.  If the system property <code>socksProxyHost</code> is
	 *	set, a <code>SOCKSConnectionHandler</code> is installed; otherwise
	 *	if <code>http.proxyHost</code> or <code>proxyHost</code> are set,
	 *	a <code>HTTPConnectionHandler</code> is installed; otherwise
	 *	a <code>DirectConnectionHandler</code> is installed.  (In all three
	 *	cases the default (no args) constructor of the connection handler
	 *	is called.)
	 *
	 *	@since			1.0
	 */
	public Session() {}

	/**
	 *	Creates a single Yahoo session, using the prescribed connection
	 *	handler.
	 *
	 *	@param ch		connection handler
	 *	@since			1.0
	 */
	public Session(ConnectionHandler ch) {}

	/**
	 *	Adds a listener object to receive events from the session.  This
	 *	should be done ASAP after creating a new session, and before login
	 * 	is called, as without it any application using this API will be
	 *	effectively deaf (but not mute).
	 *	<p>
	 *	Multiple listeners may be added for a single session, but
	 *	duplicates are ignored.  The order in which each listener is
	 *	served a given event is not guaranteed - do not assume the
	 *	event handlers will be called in the same order that the
	 *	listeners were registered.
	 *
	 *	@param ss		the event listener to add
	 *	@since			1.0
	 *	@see			#removeSessionListener(SessionListener ss)
	 */
	public void addSessionListener(SessionListener ss) {}

	/**
	 *	Removes a listener object to receive events from the session.  Has
	 *	no effect if listener not already registered.
	 *
	 *	@param ss		the event listener to remove
	 *	@since			1.0
	 *	@see			#addSessionListener(SessionListener ss)
	 */
	public void removeSessionListener(SessionListener ss) {}

	/**
	 *	Returns the currently employed connection handler.
	 *
	 *	@since			1.0
	 *	@return			current connection handler
	 */
	public ConnectionHandler getConnectionHandler() {}

	/**
	 *	Requests the session be logged in.  It is advised that a
	 *	<code>SessionListener</code> be registered with the session before
	 *	this method is called.  After calling this method (which will block
	 *	until logon is complete) <code>getSessionStatus</code> should be
	 *	checked to see if the login attempt was successful.  Unsuccessful
	 *	<code>Session objects</code> must be <code>reset</code> before being
	 *	re-used.
	 *	<p>
	 *	Yahoo doesn't really have a good line in error conditions.  We
	 *	either logged in or we failed, although the overwhelming source of
	 *	errors (barring poor network connections) will come from bad
	 *	usernames and/or passwords.  This method throws two exceptions
	 *	which are subclasses of <code>YahooException</code> - the first
	 *	is <code>AccountLockedException</code> and the second is
	 *	<code>LoginRefusedException</code>.  Both indicate a failure to
	 *	log into the Yahoo service.  The first typically carries a
	 *	<code>URL</code> of a Web page to display when the account is
	 *	locked - usually the generic Yahoo login page.
	 *	<p>
	 *	Usernames are converted to lower case, as Yahoo's usernames are case
	 *	insensitive.
	 *	<p>
	 *	The property <code>ymsg.network.loginTimeout</code> can be used to
	 *	specify a timeout, in seconds, after which the method will throw an
	 *	<code>IOException</code>.  A value of zero or below disables the
	 *	timeout facility.
	 *
	 *	@param u		Yahoo username of the account to be connected to
	 *	@param p		password of said Yahoo account
	 *	@since			1.0
	 *	@see			#logout()
	 *	@see			#getSessionStatus()
	 *	@see			#reset()
	 *	@throws	IllegalStateException if already logged in
	 *	@throws IOException if i/o problems from underlying streams or timeout
	 *	@throws AccountLockedxception if Yahoo is blocking the account
	 *	@throws LoginRefusedException if the username/password is refused
	 */
	public synchronized void login(String u,String p)
	throws IllegalStateException,IOException,AccountLockedException,LoginRefusedException {}

	/**
	 *	Requests the session be logged out (disconnected).  This will
	 *	terminate the current Yahoo session.  A session object can be
	 *	re-used after logout.
	 *
	 *	@since			1.0
	 *	@see			#login(String u,String p)
	 *	@throws	IllegalStateException if not logged in
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public synchronized void logout() throws IllegalStateException,IOException {}

	/**
	 *	Resets a spent session so the object can be re-used.  (Hey - let's be
	 *  kind to the garbage collector! :-)   Should be used after an
	 *	unsuccessful login.
	 *
	 *	@since			1.0
	 *	@see			#login(String u,String p)
	 *	@see			#logout()
	 *	@throws			IllegalStateException if still logged in.
	 */
	public synchronized void reset() throws IllegalStateException {}

	// -----------------------------------------------------------------

	/**
	 *	Sends a message.
	 *
	 *	@param to		Yahoo id of person to send message to
	 *	@param msg		Text of message (ASCII or UTF-8 please!)
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void sendMessage(String to,String msg)
	throws IllegalStateException,IOException {}

	/**
	 *	Sends a message, using a specific identity.
	 *
	 *	@param to		Yahoo id of person to send message to
	 *	@param msg		Text of message (ASCII or UTF-8 please!)
	 *	@param yid		Yahoo id (alias) to send the message as
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 *	@throws IllegalIdentityException if the user does not 'own' the supplied identity
	 */
	public void sendMessage(String to,String msg,YahooIdentity yid)
	throws IllegalStateException,IOException,IllegalIdentityException {}

	/**
	 *	Sends a buzz message.  The standard Yahoo client deals with
	 *	this type of message by displaying a BUZZ message and vibrating
	 *	the messaging window for a second or so.
	 *
	 *	@param to		Yahoo id of person to send buzz to
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void sendBuzz(String to)
	throws IllegalStateException,IOException {}

	/**
	 *	Sends a buzz message, using a specific identity.  The standard 
	 *	Yahoo client deals with this type of message by displaying a BUZZ 
	 *	message and vibrating the messaging window for a second or so.
	 *
	 *	@param to		Yahoo id of person to send buzz to
	 *	@param yid		Yahoo id (alias) to send the message as
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 *	@throws IllegalIdentityException if the user does not 'own' the supplied identity
	 */
	public void sendBuzz(String to,YahooIdentity yid)
	throws IllegalStateException,IOException,IllegalIdentityException {}

	// -----------------------------------------------------------------

	/**
	 *	Gets the status of the connection.  This will be either
	 *	<code>UNSTARTED</code> when idle and ready to go, <code>AUTH</code>
	 *	when currently engaged in trying to log in, <code>MESSAGING</code>
	 *	when successfully connected or <code>FAILED</code> when a login was
	 *	unsuccessful.
	 *	<p>
	 *	Note: DO NOT confuse this with the status of the Yahoo user
	 *	themself.  The session status documents the state of the network
	 *	connection to the Yahoo service.  The Yahoo status (see
	 *	<code>getStatus</code> and <code>setStatus</code>) documents the
	 *	state of the Yahoo user to the 'outside world' (ie: available, busy,
	 *	not in the office, etc).
	 *
	 *	@since			1.0
	 *	@see			StatusConstants
	 *	@return			session status code
	 */
	public int getSessionStatus() {}

	// -----------------------------------------------------------------

	/**
	 *	Returns the actual status of the Yahoo user.  For example available,
	 *	busy, invisible etc.  See the constants in the StatusConstants interface.
	 *
	 *	@since			1.0
	 *	@see			#setStatus(long s)
	 *	@return			unsigned 32 bit Yahoo status
	 */
	public long getStatus() {}

	/**
	 *	Sets the status of the Yahoo user.  See the constants in the
	 *	StatusConstants interface.  Note: status can only be set
	 *	initially to available or invisible, prior to logging in.
	 *
	 *	@param s		status integer, preferably from StatusConstants
	 *	@see			#getStatus()
	 *	@see			#setStatus(String m,boolean b)
	 *	@since			1.0
	 *	@throws	IllegalArgumentException if the status is set to something
	 *					other than available or invisible and the session
	 *					is unstarted.
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public synchronized void setStatus(long s)
	throws IllegalArgumentException,IOException {}

	/**
	 *	Sets the status of the Yahoo user using custom status.  This method
	 *	attempts to set the Yahoo status to the message and flag provided.
	 *
	 *	@param m		custom message text
	 *	@param b		busy (true) or available (false) flag - busy changes the
	 *					user's smiley face icon to feature a no-entry sign
	 *	@see			#getStatus()
	 *	@see			#setStatus(long s)
	 *	@since			1.0
	 *	@throws	IllegalArgumentException if the session is unstarted (only
	 *					available or invisible allowed) or the message is null.
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public synchronized void setStatus(String m,boolean b)
	throws IllegalArgumentException,IOException {}

	/**
	 *	Returns the custom status message.  When the current status is not
	 *	set to custom, this method returns null.
	 *
	 *	@return			custom status text
	 *	@see			#isCustomBusy()
	 *	@since			1.0
	 */
	public String getCustomStatusMessage() {}
	/**
	 *	Returns the custom status busy flag.  True implies the custom status
	 *	will be shown as busy (with a no entry logo over the smiley).
	 *
	 *	@return			custom status flag
	 *	@see			#getCustomStatusMessage()
	 *	@since			1.0
	 */
	public boolean isCustomBusy() {}

	// -----------------------------------------------------------------

	/**
	 *	Requests a refresh of status and new mail count from server.
	 *	The server may respond by sending back status and new mail
	 *	messages shortly after.
	 *
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 *	@since			1.0
	 */
	public void refreshStats()
	throws IllegalStateException,IOException {}

	// -----------------------------------------------------------------

	/**
	 *	Returns a list of valid identities for this Yahoo account.  These
	 *	may be used to send messages under different aliases in those methods
	 *	which support an optional <code>YahooIdentity</code> parameter.
	 *	<p>
	 *	Do not rely on the order of these identities in the array.  To find
	 *	an identity object with a given username, search the array, do not
	 *	assume it will always be at the same index.
	 *
	 *	@return			an array of valid YahooIdentity objects, or null
	 *					if not logged in
	 *	@since			1.0
	 */
	public YahooIdentity[] getIdentities() {}

	/**
	 *	Returns the true identity for this Yahoo account.  This is the
	 *	identity which was originally used to create the accoun (?) and to
	 *	which all other identities are merely aliases.
	 *
	 *	@return			the YahooIdentity object of the true identity,
	 *					or null if not logged in
	 *	@since			1.0
	 */
	public YahooIdentity getPrimaryIdentity() {}
	/**
	 *	Returns the login identity for this Yahoo account.  This is the
	 *	default identity, which was used to log into the account for this
	 *	session.
	 *
	 *	@return			the YahooIdentity object of the login identity, 
	 *					or null if not logged in
	 *	@since			1.0
	 */
	public YahooIdentity getLoginIdentity() {}

	/**
	 *	Activates or deactivates a Yahoo identity.  An activated identity 
	 *	will appear to be logged in.  A deactivated identity will appear to
	 *	be off-line.
	 *	<p>
	 *	The primary identity cannot be deactivated.  Attempting to call this
	 *	method with the primary identity, either for activation or
	 *	deactivation, will result in an <code>IllegalIdentityException</code>.
	 *
	 *	@param yid		Yahoo id (alias) to de/activate
	 *	@param activate	true to activate, false to deactivate
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IllegalIdentityException if the user does not 'own' the supplied identity
	 *					or the primary identity is used
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void activateIdentity(YahooIdentity yid,boolean activate)
	throws IllegalStateException, IllegalIdentityException, IOException {}

	// -----------------------------------------------------------------

	/**
	 *	Sets the AWT component being used for typing notification.
	 *	<p>
	 *	Yahoo sends out notification packets whenever it knows you are
	 *	typing a message to someone (yes - it sounds like a waste of network
	 *	bandwidth to me too... but never the less, this is what it does!).
	 *	These messages can be automatically generated if you provide an AWT
	 * 	component for the jYMSG API to monitor.  A listener will be registered
	 *	with the target component to monitor key presses, and notification
	 *	packets automatically sent at intervals.
	 *	<p>
	 *	Only one notification handler can be set for each target user.
	 *	Attempts to add a second, without first removing the current one, will
	 *	be ignored.
	 *	<p>
	 *	For clients which do not use AWT or Swing, the notification system
	 *	now supports a <i>manual</i> scheme for sending typing events.  To use
	 *	the manual scheme, call this method with a null component parameter,
	 *	then use <code>keyTyped</code> to inform the session of each key press.
	 *	<p>
	 *	<i>Note: DO NOT use this feature for conferences, only regular one to
	 *	one style messages.</i>
	 *
	 *	@param user		Yahoo id to send notifications to
	 *	@param com		AWT component to monitor for key presses, or null
	 *	@see			#removeTypingNotification(String user)
	 *	@see			#keyTyped(String user)
	 *	@since			1.0
	 */
	public void addTypingNotification(String user,Component com) {}

	/**
	 *	Clears the AWT component being used for typing notification.
	 *	<p>
	 *	Yahoo sends out notification packets when it knows you are
	 *	typing to someone.  The jYMSG API can generate these automatically.
	 *	This method clears the current AWT component being monitored.
	 *	Specifically, it attempts to unregister it's key event listener.
	 *	It has no effect if an event source has not already been set.
	 *
	 *	@param user		Yahoo id to stop notifcations for
	 *	@see			#addTypingNotification(String user,Component com)
	 *	@since			1.0
	 */
	public void removeTypingNotification(String user) {}

	/**
	 *	Manually update key notification.  This method is designed to be used
	 *	in clients which wish to employ key notification, but do not use AWT
	 *	or Swing components.  <code>addTypingNotfication</code> can be called
	 *	with a null component, then this method used to manually inform the
	 *	notification thread of each key press.  The notification thread will
	 *	dispatch notify packets, as necessary.
	 *	<p>
	 *	<i>Note: this method can also be used to send 'fake' key presses to
	 *	notifiers which <b>are</b> registered with an AWT/Swing component -
	 *	although there is no legitimate reason to do this.</i>
	 *
	 *	@param user		Yahoo id to 'fake' a key notifcation for
	 *	@see			#addTypingNotification(String user,Component com)
	 *	@since			1.0
	 */
	public void keyTyped(String user) {}

	// -----------------------------------------------------------------

	/**
	 *	Gets a copy of the array of groups containing Yahoo friends.  Each
	 *	group is a vector containing zero or more <code>YahooUser</code>
	 *	objects.  Each friend is represented by a specific object unique to
	 *	that user id.  if a friend appears more than once, either within a
	 *	single group or in more than one group, then the same
	 *	<code>YahooUser</code> object will be referenced.
	 *	<p>
	 *	This method will return null if the session is not connected.
	 *	<p>
	 *	<i>Note: this method returns a clone of the array, not the original,
	 *	which makes it more expensive than simply returning a reference -
	 *	avoid calling this method repeately inside a tight loop.</i>
	 *
	 *	@return			an array of group objects, or null if not connected
	 *	@see			#getUsers()
	 *	@since			1.0
	 */
	public YahooGroup[] getGroups() {}

	/**
	 *	Returns a hashtable of all users known by this session.  The hash has
	 *	their Yahoo id string as its key, and holds <code>YahooUser</code>
	 *	objects for every user that this session has come into contact with,
	 *	either via the friends group listing, or because they were in a chat
	 *	room the session visited.
	 *	<p>
	 *	There is no ability to maintain the details or status of Yahoo users
	 *	which the session is no longer in contact with.  If we leave a chatroom,
	 *	although the member's objects will remain, they will not necessarily
	 *	get updated (unless the session is also connected with that user via
	 *	another path - such as if they are in a friends group).
	 *
	 *	@return			hashtable of users
	 *	@since			1.0
	 */
	public Hashtable getUsers() {}


	/**
	 *	Returns the object for the given Yahoo id string.  The method does
	 *	not contact the Yahoo service, and cannot be used to query random 
	 *	Yahoo users 'at large'.
	 *	<p>
	 *	Looking up users is handy when a message comes in and we quickly need 
	 *	to check if the sender is ignored, a friend, or something similar.  Use 
	 *	the accessor methods on the returned <code>YahooUser</code> object to 
	 *	determine a user's status.
	 *	<p>
	 *	This method will return null if the Yahoo id is unknown.  Unknown
	 *	users are those who have not already come to the session's attention 
	 *	(via the friends list, for example).
	 *	<p>
	 *	Take note of the issues with maintaining accurate status details, as
	 *	mentioned in the <code>getUsers</code> method above.
	 *	
	 *
	 *	@param id		string id of Yahoo user
	 *	@return			a yahoo user object, or null
	 *	@since			1.0
	 */
	public YahooUser getUser(String id) {}

	/**
	 *	Returns the Imvironment string passed to the client during login.
	 *	(Note: this method may be replaced if this API ever provides fuller
	 *	support for IMvironments.)
	 *
	 *	@return			IMvironment string
	 *	@since			1.0
	 */
	public String getImvironment() {}

	/**
	 *	Returns the three cookies Yahoo sends the client upon successful login.
	 *	The cookies are in the following indexes (from 0 to 2) : Y, T then C.
	 *
	 *	@return			Cookie array
	 *	@since			1.0
	 */
	public String[] getCookies() {}

	// -----------------------------------------------------------------

	/**
	 *	Creates a new conference.  The specified users (Yahoo id's) are
	 *	contacted with an invite to join, containing the supplied message.
	 *	<p>
	 *	This method returns a conference name string, which is used to
	 *	identify this specific conference when using other conference methods.
	 *	<p>
	 *	Do not put the current user, or any of their identities, into the 
	 *	<code>users</code> list.  For logistics, jYMSG maintains a sharp 
	 *	distinction between conferences created by the user, and those 
	 *	the user was invited to.  Inviting yourself to your own conference 
	 *	will confuse matters.  (At some point this restiction may be lifted.)
	 *
	 *	@param users	array of Yahoo id's to invite
	 *	@param msg		invite message / topic
	 *	@return			conference object
	 *	@see			#extendConference(YahooConference room,String user,String msg)
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws	IllegalIdentityException if the 'users' array contains the current user
	 */
	public YahooConference createConference(String[] users,String msg)
	throws IllegalStateException,IOException {}

	/**
	 *	Creates a new conference, using a specific identity.  The specified 
	 *	users (Yahoo id's) are contacted with an invite to join, containing 
	 *	the supplied message.
	 *	<p>
	 *	The identity used to create the conference is stored as part of the
	 *	<code>YahooConference</code> object, with all subsequent calls using
	 *	said conference object automatically using this identity.
	 *	<p>
	 *	This method returns a conference name string, which is used to
	 *	identify this specific conference when using other conference methods.
	 *	<p>
	 *	Do not put the current user, or any of their identities, into the 
	 *	<code>users</code> list.  For logistics, jYMSG maintains a sharp 
	 *	distinction between conferences created by the user, and those 
	 *	the user was invited to.  Inviting yourself to your own conference 
	 *	will confuse matters.  (At some point this restiction may be lifted.)
	 *
	 *	@param users	array of Yahoo id's to invite
	 *	@param msg		invite message / topic
	 *	@return			conference object
	 *	@see			#extendConference(YahooConference room,String user,String msg)
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IllegalIdentityException if the user does not 'own' the supplied identity
	 *	@throws	IllegalIdentityException if the 'users' array contains the current user
	 */
	public YahooConference createConference(String[] users,String msg,YahooIdentity yid)
	throws IllegalStateException,IOException, IllegalIdentityException {}

	/**
	 *	Accepts a conference invite from another user.  Typically this method
	 *	would be called in response to the <code>SessionListener</code> method
	 *	<code>conferenceInviteReceived</code>.  The <code>room</code> parameter
	 *	can be found by using <code>getRoom</code> in <code>SessionConferenceEvent</code>.
	 *
	 *	@param room		conference object
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws	NoSuchConferenceException if no such conference exists
	 *					(this should <b>never</b> happen, unless called outside
	 *					an invite event!)
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void acceptConferenceInvite(YahooConference room)
	throws NoSuchConferenceException,IOException,IllegalStateException {}

	/**
	 *	Decline a conference invite from another user.  Typically this method
	 *	would be called in response to the <code>SessionListener</code> method
	 *	<code>conferenceInviteReceived</code>.  The <code>room</code> parameter
	 *	can be found by using <code>getRoom</code> in <code>SessionConferenceEvent</code>.
	 *
	 *	@param room		conference object
	 *	@param msg		rejection message
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws	NoSuchConferenceException if no such conference exists
	 *					(this should <b>never</b> happen, unless called outside
	 *					an invite event!)
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void declineConferenceInvite(YahooConference room,String msg)
	throws NoSuchConferenceException,IOException,IllegalStateException {}

	/**
	 *	Invites a user to an existing conference.  The specified user (Yahoo id's)
	 *	is contacted with an invite to join, containing the supplied message.
	 *	<p>
	 *	See <code>createConference</code> for notes on the restriction on
	 *	identities of the current user.
	 *
	 *	@param room		conference object
	 *	@param user		Yahoo id of user to invite
	 *	@param msg		invite message / topic
	 *	@see			#createConference(String[] users,String msg)
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws	NoSuchConferenceException if no such conference exists
	 *	@throws IOException if i/o problems from underlying streams
	 *	@throws	IllegalIdentityException if 'user' is the current user
	 */
	public void extendConference(YahooConference room,String user,String msg)
	throws NoSuchConferenceException,IOException,IllegalStateException {}

	/**
	 *	Sends a message to users in a conference.
	 *
	 *	@param room		conference object
	 *	@param msg		message text
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws	NoSuchConferenceException if no such conference exists
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void sendConferenceMessage(YahooConference room,String msg)
	throws NoSuchConferenceException,IOException,IllegalStateException {}

	/**
	 *	Leaves a conference.
	 *
	 *	@param room		conference object
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws	NoSuchConferenceException if no such conference exists
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void leaveConference(YahooConference room)
	throws NoSuchConferenceException,IOException,IllegalStateException {}

	// -----------------------------------------------------------------

	/**
	 *	Add a user to a group.  If the group does not exist in the current
	 *	list, it will automatically be created.
	 *	<p>
	 *	<i>Note: A request packet will be sent to the specified user (if
	 *	they are offline if will be held for them and delivered at the
	 *	earliest available time) giving them a chance to reject your
	 *	addition, causing their Yahoo id to be removed from your friends
	 *	list.  The event method <code>contactRejectionReceived</code> will
	 *	be called when confirmation of a refusal is received (please
	 *	remember, this may be some time, even days, after we added the
	 *	user).</i>
	 *
	 *	@param friend	Yahoo id of friend to add
	 *	@param group	group name
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void addFriend(String friend,String group) throws IllegalStateException {}

	/**
	 *	Remove a friend from a group.  If the group becomes empty it will
	 *	automatically be deleted.
	 *
	 *	@param friend	Yahoo id of friend to remove
	 *	@param group	group name
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void removeFriend(String friend,String group) throws IllegalStateException {}

	/**
	 *	Reject an offer to be added to a friends list.  Typically this method
	 *	will be called in response to the <code>SessionListener</code> method
	 *	<code>contactRequestReceived</code>.  The <code>getFrom</code> method
	 *	of <code>SessionEvent</code> will reveal the id of the user who is
	 *	trying to add us to their list.
	 *	<p>
	 *	<i>Note: the way Yahoo works with regard to friends lists is unusual.
	 *	It is the responsibility of the target to reject unwanted attempts to
	 *	add them to other user's lists.  If the target does nothing, the
	 *	attempt is successful (indeed, the intended way to allow yourself to
	 *	be added to someone else's list is to just ignore their request -
	 *	without a refusal the addition stands!)</i>
	 *
	 *	@param friend	Yahoo id of contact wishing to add us to their list
	 *	@param msg		rejection message
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void rejectContact(String friend,String msg) throws IllegalStateException {}

	/**
	 *	Change the ignore status of a Yahoo user.
	 *
	 *	@param friend	Yahoo id of contact to change
	 *	@param ignore	True to ignore, false to unignore
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void ignoreContact(String friend,boolean ignore) throws IllegalStateException {}

	/**
	 *	Sends a request for the friends/groups data to be updated.  Typically
	 *	this would be called if the user selected a 'Refresh' option on the
	 *	client user interface (perhaps a menu item?) to force a manual refresh
	 *	of the friends data.
	 *	<p>
	 *	<i>Note: this method merely sends a request to Yahoo for a refresh
	 *	of the data.  The <code>SessionListener</code> should be used to
	 *	determine when (or if!) this data has arrived, via its
	 *	<code>friendsUpdateReceived</code> method.</i>
	 *
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void refreshFriends() {}

	// -----------------------------------------------------------------

	/**
	 *	Send a binary file to the specified Yahoo user.  This method employs
	 *	server upload - this API currently does not support direct Peer-to-Peer
	 *	file transfer.
	 *	<p>
	 *	There is a system properties which alters the target of a connection.
	 *	<code>ymsg.network.fileTransferHost</code> can be used to set the
	 *	host to which the connection will be made.  In reality is it highly
	 *	unlikely that this property should need to be changed from its
	 *	default: <code>filetransfer.msg.yahoo.com</code>.
	 *
	 *	@param user		the Yahoo user to send the file to
	 *	@param filename	the full filename and path of the file to send
	 *	@param msg		an accompanying message text
	 *	@since			1.0
	 *	@throws	IllegalStateException if not connected to Yahoo
	 *	@throws	FailedFileTransferException if the upload fails or is rejected
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void sendFileTransfer(String user,String filename,String msg)
	throws IllegalStateException,FileTransferFailedException,IOException {}

	/**
	 *	Saves an incoming file transfer to the specified filename.
	 *
	 *	@param ev		The event object associated with this file transfer
	 *	@param filename	The full filename and path of the file to save the
	 *					incoming data to
	 *	@since			1.0
	 *	@throws	FailedFileTransferException if the download fails
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void saveFileTransferAs(SessionFileTransferEvent ev,String filename)
	throws FileTransferFailedException,IOException {}

	/**
	 *	Saves an incoming file transfer to the specified directory.  The
	 *	filename will be obtained from the URL, however if the HTTP headers
	 *	for the download request feature a <code>Content-Disposition:</code>
	 *	header with a filename, this will be used in preference.
	 *
	 *	@param ev		The event object associated with this file transfer
	 *	@param dir		The full path of the directory to save the file to
	 *	@since			1.0
	 *	@throws	FailedFileTransferException if the download fails
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void saveFileTransferTo(SessionFileTransferEvent ev,String dir)
	throws FileTransferFailedException,IOException {}

	// -----------------------------------------------------------------

	/**
	 *	Requests a chat login, blocking until the login process is over.
	 *	Connecting to chat is a two stage process, there is a round of
	 *	hankshaking which needs to be performed before the login request
	 *	itself can be sent.  This method encapsulates both steps.  Note
	 *	that this process, coupled with a possible large volume of user
	 *	data which may be downloaded for a busy room, means that this
	 *	method may block for several seconds.
	 *	<p>
	 *	To check the outcome, use <code>getChatSessionStatus</code>.  As
	 *	with the session login itself, an unsuccessful chat login must be
	 *	reset by using <code>resetChatStatus</code> before a second login
	 *	can be attempted.
	 *	<p>
	 *	The property <code>ymsg.network.loginTimeout</code> can be used to
	 *	specify a timeout, in seconds, after which the method will throw an
	 *	<code>IOException</code>.  A value of zero or below disables the
	 *	timeout facility.
	 *	<p>
	 *	Yahoo only permits a session to be logged into one lobby at a time.
	 *	Joining a second lobby will result in being removed from the first.
	 *	(Don't blame me - blame Yahoo!)
	 *
	 *	@param ycl		the chat lobby to join
	 *	@since			1.0
	 *	@throws	IllegalStateException if already logged into a lobby
	 *	@throws IOException if i/o problems from underlying streams
	 *	@throws LoginRefusedException if the room is inaccessible/full
	 */
	public synchronized void chatLogin(YahooChatLobby ycl)
	throws IllegalStateException,IOException,LoginRefusedException {}

	/**
	 *	Requests a chat login, using a specific identity, blocking until the 
	 *	login process is over.  Connecting to chat is a two stage process, 
	 *	there is a round of hankshaking which needs to be performed before the 
	 *	login request itself can be sent.  This method encapsulates both steps.
	 *	Note that this process, coupled with a possible large volume of user
	 *	data which may be downloaded for a busy room, means that this
	 *	method may block for several seconds.
	 *	<p>
	 *	To check the outcome, use <code>getChatSessionStatus</code>.  As
	 *	with the session login itself, an unsuccessful chat login must be
	 *	reset by using <code>resetChatStatus</code> before a second login
	 *	can be attempted.
	 *	<p>
	 *	The property <code>ymsg.network.loginTimeout</code> can be used to
	 *	specify a timeout, in seconds, after which the method will throw an
	 *	<code>IOException</code>.  A value of zero or below disables the
	 *	timeout facility.
	 *	<p>
	 *	Yahoo only permits a session to be logged into one lobby at a time.
	 *	Joining a second lobby will result in being removed from the first.
	 *	(Don't blame me - blame Yahoo!)
	 *
	 *	@param ycl		the chat lobby to join
	 *	@since			1.0
	 *	@throws	IllegalStateException if already logged into a lobby
	 *	@throws IOException if i/o problems from underlying streams
	 *	@throws IllegalIdentityException if the user does not 'own' the supplied identity
	 *	@throws LoginRefusedException if the room is inaccessible/full
	 */
	public synchronized void chatLogin(YahooChatLobby ycl,YahooIdentity yid)
	throws IllegalStateException,IOException,LoginRefusedException,IllegalIdentityException {}

	/**
	 *	Requests to be logged out of a chat room.  Having left, a session
	 *	can log into another (or the same) lobby by simply using
	 *	<code>chatLogin</code> again.
	 *
	 *	@since			1.0
	 *	@throws	IllegalStateException if not logged into a lobby
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public synchronized void chatLogout()
	throws IllegalStateException,IOException {}

	/**
	 *	Send a message to the current chatroom lobby.
	 *	<p>
	 *	<i>Note: Yahoo does not echo the message back to the sending client,
	 *	so to maintain a correct transcript on the client GUI, a well-behaved
	 *	application should parrot the message to the chat display as well as
	 *	transmitting it.</i>
	 *
	 *	@param	msg		Text of message (ASCII or UTF-8 please!)
	 *	@since			1.0
	 *	@throws	IllegalStateException if not logged into a lobby
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void sendChatMessage(String msg)
	throws IllegalStateException,IOException {}

	/**
	 *	Send a message to the current chatroom lobby, marked as an emote.
	 *	<p>
	 *	<i>Note 1: Yahoo does not echo the message back to the sending client,
	 *	so to maintain a correct transcript on the client GUI, a well-behaved
	 *	application should parrot the message to the chat display as well as
	 *	transmitting it.</i>
	 *	<p>
	 *	<i>Note 2: The <code>ymsg.support</code> package has an <code>EmoteManager</code>
	 *	class which can be used to handle arrays of Emote strings.</i>
	 *
	 *	@param	emote	Text of message (ASCII or UTF-8 please!)
	 *	@since			1.0
	 *	@throws	IllegalStateException if not logged into a lobby
	 *	@throws IOException if i/o problems from underlying streams
	 */
	public void sendChatEmote(String emote)
	throws IllegalStateException,IOException {}

	/**
	 *	Returns the current chatroom lobby, or null if not logged into
	 *	a chatroom.
	 *
	 *	@since			1.0
	 *	@return			a <code>YahooChatLobby</code>, of null
	 */
	public YahooChatLobby getCurrentChatLobby() {}

	/**
	 *	Returns the status of the chat <i>connection</i>.  This can be
	 *	<code>UNSTARTED</code> when idle, <code>CONNECT</code> during the
	 *	handshaking stage of connecting to a room, <code>LOGON</code> when
	 *	in the second stage, <code>MESSAGING</code> when successfully
	 *	connected or <code>FAILED</code> when a login was unsuccessful.
	 *
	 *	@since			1.0
	 *	@return			chat session status code
	 */
	public int getChatSessionStatus() {}

	/**
	 *	Resets a failed chat login.
	 *
	 *	@since			1.0
	 *	@throws			IllegalStateException if still logged in.
	 */
	public void resetChat() throws IllegalStateException {}
}
