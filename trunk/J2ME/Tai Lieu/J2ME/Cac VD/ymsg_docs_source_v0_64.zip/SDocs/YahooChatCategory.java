package ymsg.network;

import java.io.*;
import java.net.URL;
import java.util.*;

/**
 *	Represents a chatroom category.  Categories are like directories - each 
 *	category may contain more categories (sub-directories), a list of public 
 *	chatrooms and a list of private chatrooms.  Each room is further sub-divided 
 *	into lobbies which hold a limited number of users at one time.  The
 *	YahooChatCategory class is used to form the thickest branches of this tree,
 *	and as such is the starting-point for accessing the Yahoo chat system.
 *	<p>
 *	The category data is loaded from Yahoo's servers via a special type of HTTP
 *	(web) call, returning an XML document listing catrgories and their 
 *	sub-categories as a tree like structure.  Each category contains at least 
 *	one non-zero entry of the following type:
 *	<ul>
 *	<li>Zero or more sub-categories.
 *	<li>Zero or more public (Yahoo) chatrooms.
 *	<li>Zero or more private (user) chatrooms.
 *	</ul>
 *	(It is not possible to have a category with no sub-categories, as well as 
 *	no rooms!)
 *	<p>
 *	These structures are held as <code>Vector</code> objects and can be accessed
 *	via the appropriate methods of this class.  A call to inspect the public or 
 *	private rooms of a category will trigger a further download of data from 
 *	Yahoo's servers, for each individual category inspected.  <b>It is therefore 
 *	recommended that any GUI breaks the hierarchy up into two sections - a tree 
 *	of categories, then a list of rooms in that category, displayed (and therefore 
 *	downloaded) only when the category is selected.</b>
 *	<p>
 *	The jYMSG API caches data loaded from Yahoo, so revisiting a category does
 *	not necessarily force it to reload.  The category tree hardly ever changes -
 *	even so, a timeout feature should ideally be introduced to invalidate the data 
 *	when past a certain age, to cater for extreme users who leave either IM 
 *	software running for weeks at a time without a restart.  API users should 
 *	not rely on an instant response upon subsequent revisits to a category, in 
 *	case such a feature is added at a later date.)
 *	<p>
 *	Rooms information changes on an occassional basis, particularly adding
 *	and removing lobbies.  This data is also cached when loaded, but can be
 *	manually reloaded using the <code>refresh</code> method of this class.
 *	<p>
 *	<i>Note: there is no requirement to actually log into Yahoo before reading
 *	category, room or lobby information.  However, the <code>Session</code>
 *	object must be connected before a user can actually enter a desired 
 *	chatroom lobby.</i>
 *	<p>
 *	<font color="Red"><b>Future proof warning</b> : <i>It has been pointed out 
 *	that the static <code>loadCategories</code> methods used to load the 
 *	category hierarchy are not locale friendly.  In a future version of jYMSG 
 *	these methods may be replaced with a non-static mechanism, which allows
 *	multiple hierarchies to be used.  This will mean chat room data from
 *	different Yahoo locales (not just the US) could be usable side-by-side
 *	within a single session.</i></font>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class YahooChatCategory
{	/**
	 *	Returns a list of public (Yahoo) rooms for this category.  The list is
	 *	in the form of a <code>Vector</code> of <code>YahooChatRoom</code> objects.
	 *	This data is loaded if not already present for this category.  The list
	 *	may be zero length.
	 *
	 *	@throws IOException If i/o problems from underlying streams
	 *	@return			list of public room objects
	 *	@since			1.0
	 */
	public Vector getPublicRooms() {}
	
	/**
	 *	Returns a list of private (user) rooms for this category.  The list is
	 *	in the form of a <code>Vector</code> of <code>YahooChatRoom</code> objects.
	 *	This data is loaded if not already present for this category.  The list
	 *	may be zero length.
	 *
	 *	@throws IOException If i/o problems from underlying streams
 	 *	@return			list of private room objects
	 *	@since			1.0
	 */
	public Vector getPrivateRooms() {}

	/**
	 *	Forces a re-read of the public and private rooms data for this category.
	 *	
	 *	@throws IOException If i/o problems from underlying streams
	 *	@since			1.0
	 */
	public void refresh() {}
	
	/**
	 *	Returns a list sub-categories for this category.  The list is in the 
	 *	form of a <code>Vector</code> of <code>YahooChatConference</code> objects.
	 *	The list may be zero length.
	 *
 	 *	@return			list of category objects
	 *	@since			1.0
	 */
	public Vector getCategories() {}
	
	/**
	 *	Returns the title of this category.
	 *	
	 *	@return			the category name (title)
	 *	@since			1.0
	 */
	public String getName() {}

	/**
	 *	Returns the unique ID number for this category.  Under normal 
	 *	circumstances, jYMSG API users should not need to bother with this -
	 *	it is merely internal detail.
	 *	
	 *	@return			category id
	 *	@since			1.0
	 */
	public long getId() {}
	
	/**
	 *	Top-level method which loads the entire chat category tree.  This static
	 *	method is the starting point for using Yahoo chatrooms.  The data loaded
	 *	by this method is cached to speed up future calls.
	 *	<p>
	 *	The YahooChatCategory object returned by this method is a dummy 'root'
	 *	object - the Yahoo category hierarchy does not have a single root
	 *	node of its own, so an artificial root is created.  This root object is
	 *	guarantedd therefore to have no public or private rooms, and always have
	 *	at least one category (unless something has gone horribly wrong!)
	 *	<p>
	 *	<i>Note 1: this method does not depend upon a <code>Session</code>
	 *	object to work.  It can be used without logging into Yahoo.</i>
	 *	<p>
	 *	<i>Note 2: the name and ID fields of the root object have no purpose.
	 *	<code>getName</code> returns the default string &lt;root&gt;, while 
	 *	<code>getId</code> returns the generation timestamp included in the 
	 *	XML category data loaded from Yahoo.  Neither values should be relied
	 *	upon in future releases.  A formalised way of accessing the timestamp
	 *	may be introduced in later versions.</i>
	 *	<p>
	 *	<i>Note 3: also: the data returned by this method will not contain any 
	 *	adult group listings.  To get those, cookies from an appropriate user
	 *	account must be sent when the data is requested.  See the overloaded 
	 *	method <code>loadCategories(Session session)</code> for more.</i>
	 *	<p>
	 *	<font color="Red">See future proof warning at the top of the page.</font>
	 *
	 *	@throws IOException if i/o problems from underlying streams
	 *	@return			root category object
	 *	@since			1.0
	 */
	public static YahooChatCategory loadCategories() {}

	/**
	 *	User-specific version of parameter-less <code>loadCategories</code>
	 *	method, used to fetch the root of the chat category tree.  Functions 
	 *	identically to its counterpart, except the cookies from the supplied 
	 *	<code>Session</code> object are remembered, and transmitted as part 
	 *	of each request.
	 *	<p>
	 *	If the supplied <code>Session</code> is null, or its 
	 *	<code>getCookies</code> method returns null (because the session is
	 *	not logged in) this method functions in the same way as its overloaded
	 *	companion.
	 *	<p>
	 *	<font color="Red">See future proof warning at the top of the page.</font>
	 *
	 *	@throws IOException if i/o problems from underlying streams
	 *	@param session	a connected session object
	 *	@return			root category object
	 *	@since			1.0
	 */
	public static YahooChatCategory loadCategories(Session session) {}
	
	/**
	 *	Enables chatroom data from non-US locales to be accessed.  Pass in the
	 *	country prefix (for example "fr") without the trailing dot, and it will
	 *	be prepended to the hostname used to fetch chat category data.  This
	 *	must be done <b>before</b> the call to a <code>loadCategories</code>
	 *	method.  Pass in null to reset the URL back to the default US locale.
	 *	
	 *	This method is a stop-gap, to compensate for the fact that the 
	 *	<code>loadCategories</code> methods were designed erroneously without 
	 *	regard for non-US locales.  This method may be removed when a more 
	 *	suitable soltution is developed.
	 *	<p>
	 *	<font color="Red">See future proof warning at the top of the page.</font>
	 *
	 *	@param l		a country prefix, ie. "fr"
	 *	@since			1.0
	 */
	public static void setLocalePrefix(String l) {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
