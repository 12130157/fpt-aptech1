package ymsg.network.event;

import java.net.URL;
import java.net.MalformedURLException;

/**
 *	Represents an incoming file transfer event.  To transfer files from one
 *	client to another, Yahoo employs two methods.  The first uploads the file
 *	to a scratch area on a dedicated Yahoo server, using HTTP, and the informs
 *	the target client of the location to download the file from.  The second
 *	is a direct peer-to-peer transfer.
 *	<p>
 *	jYMSG currently only supports the first, indirect, method.
 *	<p>
 *	There are four fields of importance here: the first is <code>from</code>,
 *	which details who sent the file; the second is <code>message</code>, which
 *	details an accompanying message to display; the third is <code>timestamp</code>
 *	which documents when the uploaded file will expire (typically a week from
 *	the upload time) and the final one is <code>location</code>, which gives
 *	the URL to fetch the file from.
 *	<p>
 *	Note: The <code>Session</code> class contains two methods for easily
 *	downloading files referenced by these events: <code>saveFileTransferAs</code>
 *	and <code>saveFileTransferTo</code>.
 *	<p>
 *	<table border="2">
 *	<tr><td>&nbsp</td>
 *		<td><b>getTo</b></td>
 *		<td><b>getFrom</b></td>
 *		<td><b>getMessage</b></td>
 *		<td><b>getTimestamp</b></td>
 *		<td><b>getLocation</b></td>
 *	</tr>
 *	<tr><td><i>fileTransferReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	</table>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SessionFileTransferEvent extends SessionEvent
{	/**
	 *	Create a new instance.  API users should not call this directly.
	 *	The API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param t		to (Yahoo id)
	 *	@param f		from (Yahoo id)
	 *	@param m		message (ASCII or UTF-8)
	 *	@param dt		timestamp (seconds since epoch)
	 *	@param l		location (URL)
	 */
	public SessionFileTransferEvent(Object o,String t,String f,String m,String dt,String l){}

	/**
	 *	Returns the location of the file which was uploaded to Yahoo.  To
	 *	successfully complete the file transfer, the client should make a
	 *	connection to this location and download its contents.
	 *
	 *	@return 		the URL of the transfered file.
	 */
	public URL getLocation() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 *	@since			1.0
	 */
	public String toString() {}
}
