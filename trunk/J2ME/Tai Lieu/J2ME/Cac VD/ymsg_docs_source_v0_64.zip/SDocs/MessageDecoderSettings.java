package ymsg.support;

import java.awt.Color;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *	This class acts in tandem with the MessageDecoder, to give control
 *	over how the translated output is styled.  Rather than set these
 *	preferences inside the decoder object itself, this independent object
 *	allows for a single set of preferences to be shared between multiple
 *	decoders, and immediately updated across all.
 *	<p>
 *	The font/text settings fall into two categories.  'Default' determines
 *	the initial state of the decoder, while 'overridden' determines the
 *	settings to use to override those specified in each message.
 *	<p>
 *	For example, setting a default font will effect the way text is rendered
 *	for messages which do not set their fonts explicity.  (Not setting this
 *	will mean that the decoder will use the default style provided by Swing.)
 *	Setting an overriding font will effect the way text is rendered for
 *	messages which carry their own font details - your overriding font will
 *	always be used in preference to the message's choosen font.  (Not setting
 *	this will mean that the message fonts will be respected.)
 *	<p>
 *	To force all font faces to be Courier, for example, one would set both
 *	the default and the overriding font faces.  This will ensure that all
 *	messages without font data will be rendered using Courier (thanks to
 *	'default') and all messages *with* font data  will also be rendered
 *	using Courier (thanks to 'override').
 *	<p>
 *	Setting a field to null or -1 will have the effect of disabling that
 *	style attribute.  It is therefore quite possible to override message
 *	font faces, while not overriding their font size.  Or to set a maximum
 *	font size for messages, but no minimum.
 *	<p>
 *	Fade and alt are two ways of creating highly coloured text.  Fade
 *	provides a transitional effect evenly between an array of colours
 *	across a message.  Alt also takes an array of colours, but instead of
 *	gradually fading from colour to colour across a message, the colours
 *	are simply alternated over and over, one per character.
 *	<p>
 *	Displaying highly coloured text like fade and alt can use excessive
 *	resources, so it is recommended software provides a way to switch off
 *	fade and alt decoding.  (See the 'respect' methods provided.)
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class MessageDecoderSettings
{	/**
	 *	Set whether emoticons should be decoded as images, or left as text.
	 *
	 *	@param b		true=translate, false=leave
	 *	@since			1.0
	 */
	public void setEmoticonsDecoded(boolean b) {}
	/**
	 *	Set an emoticon loader instance.  This can be used to intergrate
	 *	bespoke emoticon images into the decoder.  See <code>EmoticonLoader</code>
	 *	for more details.  Setting this property to null disables it.
	 *
	 *	@param l		class of type EmoticonLoader, or null
	 *	@since			1.0
	 */
	public void setEmoticonLoader(EmoticonLoader l) {}


	/**
	 *	Set the default (starting) font face.  Setting this property to null
	 *	disables it.
	 *
	 *	@param s		name of default font, or null
	 *	@since			1.0
	 */
	public void setDefaultFontFace(String s) {}
	/**
	 *	Set the default (starting) font point size.  Setting this property to
	 *	-1 disables it.
	 *
	 *	@param sz		size of default font, or -1
	 *	@since			1.0
	 */
	public void setDefaultFontSize(int sz) {}
	/**
	 *	Set the default (starting) text colour.  Setting this property to null
	 *	disables it.
	 *
	 *	@param col		AWT Color of default text, or null
	 *	@since			1.0
	 */
	public void setDefaultForeground(Color col) {}

	/**
	 *	Set the overriding font face.  Any message attempting to change the
	 *	font face will be superceeded by this setting.  Setting this property
	 *	to null disables it.
	 *
	 *	@param s		name of overriding font, or null
	 *	@since			1.0
	 */
	public void setOverrideFontFace(String s) {}
	/**
	 *	Set the overriding maximum font point size.  Any message attempting to
	 *	set a font larger than this will be superceeded by this setting.
	 *	Setting this property to -1 disables it.
	 *
	 *	@param sz		max size of overriding font, or -1
	 *	@since			1.0
	 */
	public void setOverrideMaxFontSize(int sz) {}
	/**
	 *	Set the overriding minimum font point size.  Any message attempting to
	 *	set a font smaller than this will be superceeded by this setting.
	 *	Setting this property to -1 disables it.
	 *
	 *	@param sz		min size of overriding font, or -1
	 *	@since			1.0
	 */
	public void setOverrideMinFontSize(int sz) {}
	/**
	 *	Set the overriding text colour.  Any message attempting to change
	 *	the text colour will be superceeded by this setting.
	 *	Setting this property to null disables it.
	 *
	 *	@param col		AWT Color of overriding text, or null
	 *	@since			1.0
	 */
	public void setOverrideForeground(Color col) {}

	/**
	 *	Convenience method for setting all default font settings at once.
	 *	Setting these properties to null or -1 disables them.
	 *
	 *	@param face		name of default font, or null
	 *	@param sz		size of default font, or -1
	 *	@param fgCol	AWT Color of default text, or null
	 *	@since			1.0
	 */
	public void setDefaultFont(String face,int sz,Color fgCol) {}
	/**
	 *	Convenience method for setting all overriding font settings at once.
	 *	Setting these properties to null or -1 disables them.
	 *
	 *	@param face		name of overriding font, or null
	 *	@param min		min size of overriding font, or -1
	 *	@param max		max size of overriding font, or -1
	 *	@param fgCol	AWT Color of overriding text, or null
	 *	@since			1.0
	 */
	public void setOverrideFont(String face,int min,int max,Color fgCol) {}

	/**
	 *	Determines whether FADE message components will be ignored.  True
	 *	will signal to decoders that transitional text colour sections in
	 *	a message are to be respected when possible.  Default is false.
	 *	<p>
	 *	(Note: highly coloured text like this might greatly increase the
	 *	resources required to process and display said messages in UI
	 *	components.)
	 *
	 *	@param b		true if fade is to be respected
	 *	@since			1.0
	 */
	public void setRespectTextFade(boolean b) {}
	/**
	 *	Determines whether ALT message components will be ignored.  True
	 *	will signal to decoders that alternating text colour sections in
	 *	a message are to be respected when possible.  Default is false.
	 *	<p>
	 *	(Note: highly coloured text like this might greatly increase the
	 *	resources required to process and display said messages in UI
	 *	components.)
	 *
	 *	@param b		true if alt is to be respected
	 *	@since			1.0
	 */
	public void setRespectTextAlt(boolean b) {}


	/**
	 *	Returns whether emoticons will be translated to icons.
	 *
	 *	@return			true=translate, false=leave
	 *	@since			1.0
	 */
	public boolean getEmoticonsDecoded() { return emoticonsOn; }
	/**
	 *	Returns emoticon loader object, if set.
	 *
	 *	@return			emoticon loader, or null
	 *	@since			1.0
	 */
	public EmoticonLoader getEmoticonLoader() { return emoticonLoader; }

	/**
	 *	Returns default font face name, if set.
	 *
	 *	@return			string, or null
	 *	@since			1.0
	 */
	public String getDefaultFontFace() { return defFontFace; }
	/**
	 *	Returns default font size, if set.
	 *
	 *	@return			size, or -1
	 *	@since			1.0
	 */
	public int getDefaultFontSize() { return defFontSize; }
	/**
	 *	Returns default text colour, if set.
	 *
	 *	@return			AWT Color, or null
	 *	@since			1.0
	 */
	public Color getDefaultForeground() { return defFg; }

	/**
	 *	Returns overriding font face name, if set.
	 *
	 *	@return			string, or null
	 *	@since			1.0
	 */
	public String getOverrideFontFace() { return overFontFace; }
	/**
	 *	Returns overriding maximum font size, if set.
	 *
	 *	@return			size, or -1
	 *	@since			1.0
	 */
	public int getOverrideMaxFontSize() { return overMaxFontSize; }
	/**
	 *	Returns overriding minimum font size, if set.
	 *
	 *	@return			size, or -1
	 *	@since			1.0
	 */
	public int getOverrideMinFontSize() { return overMinFontSize; }
	/**
	 *	Returns overriding text colour, if set.
	 *
	 *	@return			AWT Color, or null
	 *	@since			1.0
	 */
	public Color getOverrideForeground() { return overFg; }

	/**
	 *	Returns whether fade message components are respected.
	 *
	 *	@return			true if FADE is respected, otherwise false
	 *	@since			1.0
	 */
	public boolean getRespectTextFade() { return respectFade; }
	/**
	 *	Returns whether alt message components are respected.
	 *
	 *	@return			true if ALT is respected, otherwise false
	 *	@since			1.0
	 */
	public boolean getRespectTextAlt() { return respectAlt; }
}
