package ymsg.network;

import java.net.Socket;
import java.net.SocketException;
import java.io.*;

/**
 *	Connection handler for direct connections to Yahoo.  Pass this
 *	class into the <code>Session</code> constructor to create a session
 *	which has no firewall or proxy requirements.
 *	<p>
 *	There are two system properties which alter the target of a connection.
 *	<code>ymsg.network.directHost</code> can be used to set the host to
 *	which the connection will be made.  <code>ymsg.network.directPorts</code>
 *	can be used to set a comma-separated-list of ports to be tried in
 *	order (the first number on this list is treated as the primary port).
 *	In reality is it highly unlikely that these properties should need
 *	to be changed from their defaults: <code>scs.msg.yahoo.com</code> and
 *	<code>5050,23,25,80</code>.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class DirectConnectionHandler extends ConnectionHandler
{	/**
	 *	Connect to a specific host and port.  No fallback ports will
	 *	be used if the specified port fails.
	 *
	 *	@param h		host
	 *	@param p		port number
	 *	@since			1.0
	 */
	public DirectConnectionHandler(String h,int p) {}
	/**
	 *	Connect to the default host with the specified port, and will not
	 *	resort the fallback.  This method is handy if you with to connect to
	 *	a specific port which is not the default.
	 *	<p>
	 *	For example, having initially used the default constructor (or the
	 *	boolean constructor, set to true) to employ fallback ports until a
	 *	clear path is found, the application then may use <code>getPort</code>
	 *	to discover which port was actually successful, storing this
	 *	information in a configuration file.  When restarted, the application
	 *	can then attempt to direct traffic straight to this port, avoiding
	 *	the lenghty trial-and-error process.
	 *
	 *	@param p		port number
	 *	@since			1.0
	 */
	public DirectConnectionHandler(int p) {}
	/**
	 *	Connect to the default host and port, but will not resort to
	 *	fallback ports if the parameter is true.  When parameter is set
	 *	to false, this has the same effect as the default constructor.
	 *
	 *	@param fl		false tries only the default port
	 *	@since			1.0
	 */
	public DirectConnectionHandler(boolean fl) {}
	/**
	 *	Connect to the default host and port, or try all the fallback
	 *	ports if the default port does not respond.
	 *
	 *	@since			1.0
	 */
	public DirectConnectionHandler() {}

	/**
	 *	Returns the actual host name used for this connection.
	 *
	 *	@return			host name
	 *	@since			1.0
	 */
	public String getHost() {}

	/**
	 *	Returns the actual port number used for this connection.
	 *
	 *	@return			port number
	 *	@since			1.0
	 */
	public int getPort() {}

	/**
	 *	Returns the string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
