package ymsg.support;

import java.util.Vector;
import java.util.StringTokenizer;
import java.awt.Color;
import javax.swing.text.*;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *	This class represents an element in a decoded Yahoo message.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class MessageElement implements Emoticons
{	public final static int NULL = -2;				// No meaning
	public final static int ROOT = -1;				// Root section
	public final static int TEXT = 0;				// Text data
	public final static int BOLD = 1;				// Bold container
	public final static int ITALIC = 2;				// Italic container
	public final static int COLOUR_INDEX = 3;		// Colour index 0-9 container
	public final static int UNDERLINE = 4;			// Underline container
	public final static int FONT = 5;				// Font container
	public final static int FADE = 6;				// Fade container
	public final static int ALT = 7;				// Alt container
	public final static int COLOUR_ABS = 8;			// Colour absolute #rrggbb container
	public final static int COLOUR_NAME = 9;		// Named colour <red> <blue> etc.

	/**
	 *	Translates this decoded message (from this node down) into HTML.
	 *
	 *	@return			HTML fragment string
	 *	@since			1.0
	 */
	public String toHTML() {}
	/**
	 *	Translates this decoded message (from this node down) into plain text.
	 *
	 *	@return			unstyle text
	 *	@since			1.0
	 */
	public String toText() {}
	/**
	 *	Translates and appends this decoded message (from this node down) onto 
	 *	and existing Swing Document object.
	 *
	 *	@param doc		the Swing Document to use
	 *	@since			1.0
	 */
	public void appendToDocument(Document doc) {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
