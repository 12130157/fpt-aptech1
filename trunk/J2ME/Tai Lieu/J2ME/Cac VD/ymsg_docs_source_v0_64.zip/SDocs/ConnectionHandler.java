package ymsg.network;

/**
 *	Abstract parent class for all connection handlers.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */ 
public abstract class ConnectionHandler
{
}
