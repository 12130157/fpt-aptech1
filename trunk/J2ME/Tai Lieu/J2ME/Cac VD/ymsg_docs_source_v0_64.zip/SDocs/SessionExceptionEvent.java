package ymsg.network.event;

/**
 *	Represents an exception throw from deep within the API.  These events embody
 *	significant exceptions which occur on threads which run parallel to the
 *	application using the API, and so have no easy way of 'bubbling up' to the
 *	API level.  This event gives the API a means of delivering such exceptions
 *	to the application.
 *	<p>
 *	<table border="2">
 *	<tr><td>&nbsp</td>
 *		<td><b>getException</b></td>
 *		<td><b>getMessage</b></td>
 *	</tr>
 *	<tr><td><i>inputExceptionThrown</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	</table>
 *
 *	@author			FISH
 *	@version		%I%, %G%
 *	@since			1.0
 */
public class SessionExceptionEvent extends SessionEvent
{	/**
	 *	Create a new instance. API users should not call this directly. The
	 *	API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param e		exception
	 *	@since			1.0
	 */
	public SessionExceptionEvent(Object o,String m,Exception e) {}

	/**
	 *	Return the exception for which this event was fired.
	 *
	 *	@return			exception object
	 *	@since			1.0
	 */
	public Exception getException() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 *	@since			1.0
	 */
	public String toString() {}
}
