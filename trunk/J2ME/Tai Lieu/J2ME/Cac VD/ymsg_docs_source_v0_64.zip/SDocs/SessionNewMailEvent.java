package ymsg.network.event;

/**
 *	Represents an new mail event. Yahoo likes to inform the client when
 *	there is Yahoo Mail which is unread.  This object can take two different
 *	forms; the first being simply a count of unread mail (the most common)
 *	and the second being an actual e-mail itself (yet to actually see this
 *	'in real life', but the documentation suggests it is possible).
 *	<p>
 *	The inherited method <code>getFrom</code> returns the 'real world' name of
 *	the e-mail sender (for example "John Smith") while <code>getEmailAddress</code>
 *	returns the e-mail address (for example "j.smith@test.com").
 *	<p>
 *	If present, the e-mail body (text) can be read by using the inherited
 *	<code>getMessage</code> method.
 *	<p>
 *	<table border="2">
 *	<tr><td>&nbsp</td>
 *		<td><b>getMailCount</b></td>
 *		<td><b>getFrom</b></td>
 *		<td><b>getEmailAddress</b></td>
 *		<td><b>getSubject</b></td>
 *		<td><b>getMessage</b></td>
 *	</tr>
 *	<tr><td><i>newMailReceived (v1)</i></td>
 * 		<td>y (gt. zero)</td>
 * 		<td>n</td>
 * 		<td>n(?)</td>
 * 		<td>n</td>
 * 		<td>n</td>
 *	</tr>
 *	<tr><td><i>newMailReceived (v2)</i></td>
 * 		<td>y (eq. zero)</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	</table>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SessionNewMailEvent extends SessionEvent
{	/**
	 *	Create a new instance.  API users should not call this directly.
	 *	The API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param ml		number of new Yahoo e-mails
	 *	@since			1.0
	 */
	public SessionNewMailEvent(Object o,String ml){}

	/**
	 *	Gets the number of new Yahoo e-mails.  Will return zero if this
	 *	is not a mail count, but an actual message.
	 *
	 *	@return			number of unread e-mails, or zero
	 *	@since			1.0
	 */
	public int getMailCount() {}

	/**
	 *	Returns the subject line of this mail, if this event represents
	 *	an actual e-mail, not just a count.  Otherwise returns <code>null</code>. 
	 *	@return			subject or null
	 *	@since			1.0
	 */
	public String getSubject() {}

	/**
	 *	Returns the e-mail address of the sender.
	 *
	 *	@return			address string
	 *	@since			1.0
	 */
	public String getEmailAddress() { return address; }

	/**
	 *	Returns whether this event is an actual mail, or just a count.
	 *
	 *	@return			true if it is, false if it ain't
	 *	@since			1.0
	 */
	public boolean isWholeMail() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 *	@since			1.0
	 */
	public String toString() {}
}
