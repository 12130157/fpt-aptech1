package ymsg.network;

/**
 *	Thrown when the API is asked to do something with a chatroom which
 *	does not exist.
 *
 *	@author         FISH
 *	@version        %I%, %G%
 *	@since          1.0
 */
public class NoSuchChatroomException extends java.lang.RuntimeException
{	NoSuchChatroomException(String m) {}
}
