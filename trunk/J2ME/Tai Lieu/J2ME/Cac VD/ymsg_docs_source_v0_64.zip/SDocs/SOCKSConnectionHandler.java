package ymsg.network;

import java.util.Properties;

/**
 *	Connection handler for SOCKS proxy connections to Yahoo.  Pass this
 *	class into the <code>Session</code> constructor to create a session
 *	which can work through firewalls with SOCKS gateways.
 *	<p>
 *	For more information on the Java properties used by this class, read
 *	<a href="http://java.sun.com/j2se/1.4.2/docs/guide/net/properties.html">Sun's
 *	Java Networking Properties</a> page.
 *	<p>
 *	There are two system properties which alter the target of a connection.
 *	<code>ymsg.network.directHost</code> can be used to set the host to
 *	which the connection will be made.  <code>ymsg.network.directPorts</code>
 *	can be used to set a comma-separated-list of ports to be tried in
 *	order (the first number on this list is treated as the primary port).
 *	In reality is it highly unlikely that these properties should need
 *	to be changed from their defaults: <code>scs.msg.yahoo.com</code> and
 *	<code>5050,23,25,80</code>.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SOCKSConnectionHandler extends DirectConnectionHandler
{	/**
	 *	Connect using the Java system properties <code>socksProxyHost</code>
	 *	and <code>socksProxyPort</code>.  If these are unset, this constructor
	 *	will throw an <code>IllegalArgumentException</code>.
	 *
	 *	@throws IllegalStateException If no HTTP proxy properties set
	 *	@since			1.0
	 */
	public SOCKSConnectionHandler() {}
	/**
	 *	Connect using a specific SOCKS proxy host and port.
	 *	<p>
	 *	<i>Note: this constructor sets the Java system properties
	 *	<code>socksProxyHost</code>, <code>socksProxyPort</code>.
	 *	These settings will be global throughout the JVM.</i>
	 *
	 *	@param h		SOCKS host
	 *	@param p		SOCKS port
	 *	@since			1.0
	 */
	public SOCKSConnectionHandler(String h,int p) {}

	/**
	 *	Returns the string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
