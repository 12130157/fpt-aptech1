package ymsg.network;

/**
 * Abstract top level class for all Yahoo exceptions.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public abstract class YahooException extends java.lang.Exception
{	YahooException(String m) {}
}
