package ymsg.network.event;

/**
 *	Represents an incoming notify message event.  There are two noteworthy
 *	notifications: the first (and by far the most common) is <code>TYPING</code>
 *	events, which are received when a remote user is in the process of sending
 *	a message to our client.  The second is <code>GAME</code> events.  (The
 *	current jYMSG API doesn't support games.)
 *	<p>
 *	There are two ways of determining the type of notification.  The first is
 *	to study the <code>type</code> field and compare it to the 
 *	<code>String</code>values in <code>StatusConstants</code>: 
 *	<code>NOTIFY_TYPING</code> and <code>NOTIFY_GAME</code>.  The second is to
 *	call either of the boolean methods, <code>isTyping</code> or 
 *	<code>isGame</code>.
 *	<p>
 *	The mode determines whether the notification is on or off.  0 meaning off
 *	and 1 meaning on.  Yahoo will send 'on' packets when a an 'action' starts,
 *	and 'off' when it finishs (in the case of typing, 'off' will be sent if 
 *	there is a suitable pause in typing or the message is actually transmitted.
 *	When typing restarts, 'on' will be sent).
 *	<p>
 *	For packets of a game type, the <code>game</code> field will contain
 *	the name of the game. 
 *	<p>
 *	<i>Note: Yahoo sends the game name encoded as a regular text message, 
 *	and jYMSG API uses the <code>message</code> field to store it.  
 *	<code>getGame</code> is actually just actually another name for 
 *	<code>getMessage</code>.</i>
 *	<p>
 *	<table border="2">
 *	<tr><td>&nbsp</td>
 *		<td><b>getTo</b></td>
 *		<td><b>getFrom</b></td>
 *		<td><b>getMessage</b></td>
 *		<td><b>getType</b></td>
 *		<td><b>getMode</b></td>
 *	</tr>
 *	<tr><td><i>notifyReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	</table>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SessionNotifyEvent extends SessionEvent
{	/**
	 *	Create a new instance.  API users should not call this directly.
	 *	The API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param t		to (Yahoo id)
	 *	@param f		from (Yahoo id)
	 *	@param m		message (ASCII or UTF-8)
	 *	@param ty		type (TYPING/GAME)
	 *	@param md		mode (0 or 1)
	 *	@since			1.0
	 */
	public SessionNotifyEvent(Object o,String t,String f,String m,String ty,String md){}	
	
	/**
	 *	Returns the notification mode.  Zero is off, one is on.
	 *
	 *	@return	 		mode as integer
	 *	@since			1.0
	 */
	public int getMode() {}

	/**
	 *	Returns the notification type, TYPING, GAME, etc.  See <code>
	 *	StatusConstants</code>.
	 *
	 *	@see			#isTyping()
	 *	@see			#isGame()
	 *	@return	 		type string
	 *	@since			1.0
	 */
	public String getType() {}

	/**
	 *	Returns the game name if this is a game notification, otherwise 
	 *	<code>null</code>.  (Actually a wrapper for <code>getMessage</code>.)
	 *
	 *	@return			game name
	 *	@since			1.0
	 */
	public String getGame() {}

	/**
	 *	Returns true if notification is typing type.
	 *
	 *	@see			#getType()
	 *	@return			true if typing
	 *	@since			1.0
	 */
	public boolean isTyping() {}

	/**
	 *	Returns true if notification is game type.
	 *
	 *	@see			#getType()
	 *	@return			true if game
	 *	@since			1.0
	 */
	public boolean isGame() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 *	@since			1.0
	 */
	public String toString() {}
}
