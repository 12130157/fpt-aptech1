package ymsg.network;

/**
 *	Represents a single Yahoo user that the API knows about.  This may be
 *	because they are on our friends list, because they are on our ignored
 *	list - or just because they are someone we encountered as part of a
 *	conference session, or they tried to add us to their friends list.
 *	<p>
 *	Not all fields will be filled out.  Yahoo often does not give full
 *	info on every Yahoo id included in its packets - but there should
 *	always be sufficient data to do the task at hand, whether that be
 *	sending messages to a conference, refusing a contact request, etc.
 *	<p>
 *	Yahoo does not give update information for users a session is not
 *	in direct contact with.  If we leave a chat room, for example, the
 *	YahooUser objects for its visitors will no longer be updated - unless
 *	they are also reachable via another route, for example if they are
 *	on our friends list.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class YahooUser
{	/**
	 *	Returns the Yahoo ID of this user.
	 *
	 *	@return			ID of user.
	 *	@since			1.0
	 */
	public String getId() {}

	/**
	 *	Returns the status of this user.  See the <code>StatusConstants</code>
	 *	interface for meanings.
	 *
	 *	@return			current status
	 *	@since			1.0
	 */
	public long getStatus() {}

	/**
	 *	Returns whether this user is accessing Yahoo via the chat system.
	 *
	 *	@return			true if they are, false if not.
	 *	@since			1.0
	 */
	public boolean isOnChat() {}

	/**
	 *	Returns whether this user is accessing Yahoo via the pager (Instant
	 *	Messager) system.
	 *
	 *	@return			true if they are, false if not.
	 *	@since			1.0
	 */
	public boolean isOnPager() {}

	/**
	 *	Returns whether this user is logged into Yahoo.  To be logged into
	 *	Yahoo they must either be present on chat or pager.
	 *
	 *	@return			true if they are, false if not.
	 *	@since			1.0
	 */
	public boolean isLoggedIn() {}

	/**
	 *	Returns whether messages from this user are currently ignored.  This
	 *	API does not actually filter messages itself (although this option
	 *	could be added at a later date) so it is left to the API user to
	 *	check the <code>isIgnored</code> status of each user from whom it
	 *	gets a message.
	 *
	 *	@return			true if they are, false if not.
	 *	@since			1.0
	 */
	public boolean isIgnored() {}

	/**
	 *	Returns this user's custom status message.  If this user does
	 *	not currently have custom status set, then this method returns
	 *	<code>null</code>.
	 *
	 *	@return			custom status message, or <code>null</code>
	 *	@since			1.0
	 */
	public String getCustomStatusMessage() { }

	/**
	 *	Returns whether this user's custom status is 'busy'.  The result
	 *	from this method should only be considered valid if the user actually
	 *	has a custom status set.
	 *
	 *	@return			true if they are, false if not.
	 *	@since			1.0
	 */
	public boolean isCustomBusy() {}

	/**
	 *	Returns true if this user is in one or more of the session's Friends
	 *	groups.
	 *
	 *	@return			true if they are, false if not.
	 *	@since			1.0
	 */
	public boolean isFriend() {}

	/**
	 *	Returns a string representation of this object.
	 *	
	 *	@return			user as a string
	 *	@since			1.0
	 */
	public String toString() {}
}
