package ymsg.network;

/**
 *	Thrown when login using fails, often because of a bad username or
 *	password.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class LoginRefusedException extends YahooException
{	LoginRefusedException(String m) {}

	/**
	 *	Returns the status code given by the server.  This will one of the
	 *	values specified in <code>StatusConstants</code>.  Values will be
	 *	either <code>STATUS_BADUSERNAME</code> for an unknown account, or
	 *	<code>STATUS_BAD</code> for a bad password (or other fault).
	 *
	 *	@since			1.0
	 *	@return			status value
	 */
	public long getStatus() { return status; }
}
