package ymsg.network.event;

import java.util.Date;

/**
 *	Represents an incoming message type event.  There are several fields of
 *	note here: firstly <code>from</code> which denotes who sent the message;
 *	secondly <code>message</code> which is the ASCII or UTF-8 of the message
 *	text; and finally <code>timestamp</code> which is used in some
 *	circumstances to date the message or set an expiry date.
 *	<p>
 *	<table border="2">
 *	<tr><td>&nbsp</td>
 *		<td><b>getTo</b></td>
 *		<td><b>getFrom</b></td>
 *		<td><b>getMessage</b></td>
 *		<td><b>getTimestamp</b></td>
 *	</tr>
 *	<tr><td><i>contactRejectionReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n</td>
 *	</tr>
 *	<tr><td><i>contactRequestReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	<tr><td><i>messageReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n</td>
 *	</tr>
 *	<tr><td><i>buzzReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>n</td>
 *	</tr>
 *	<tr><td><i>offlineMessageReceived</i></td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 * 		<td>y</td>
 *	</tr>
 *	<tr><td><i>listReceived/i></td>
 * 		<td>n</td>
 * 		<td>n</td>
 * 		<td>n</td>
 * 		<td>n</td>
 *	</tr>
 *	<tr><td><i>logoffReceived</i></td>
 * 		<td>n</td>
 * 		<td>n</td>
 * 		<td>n</td>
 * 		<td>n</td>
 *	</tr>
 *	</table>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class SessionEvent extends java.util.EventObject
{	/**
	 *	Create a new instance. API users should not call this directly. The
	 *	API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@since			1.0
	 */
	public SessionEvent(Object o) {}

	/**
	 *	Create a new instance. API users should not call this directly. The
	 *	API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param t		to (Yahoo id)
	 *	@param f		from (Yahoo id)
	 *	@since			1.0
	 */
	public SessionEvent(Object o,String t,String f) {}

	/**
	 *	Create a new instance. API users should not call this directly. The
	 *	API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param t		to (Yahoo id)
	 *	@param f		from (Yahoo id)
	 *	@param m		message (ASCII or UTF-8)
	 *	@since			1.0
	 */
	public SessionEvent(Object o,String t,String f,String m) {}

	/**
	 *	Create a new instance. API users should not call this directly. The
	 *	API itself will create its own events.
	 *
	 *	@param o		source of event (<code>Session</code>)
	 *	@param t		to (Yahoo id)
	 *	@param f		from (Yahoo id)
	 *	@param m		message (ASCII or UTF-8)
	 *	@param dt		timestamp (Unix, seconds)
	 *	@since			1.0
	 */
	public SessionEvent(Object o,String t,String f,String m,String dt) {}

	/**
	 *	Returns the to field, which should (if the message is legit) contain
	 *	the client's Yahoo id or one of their identities.
	 *
	 *	@return			Yahoo id
	 *	@since			1.0
	 */
	public String getTo() {}
	/**
	 *	Returns the <code>from</code> field, the Yahoo user who sent this
  	 *	message (this may be their actual id, or one of their identities).
	 *
	 *	@return			Yahoo id
	 *	@since			1.0
	 */
	public String getFrom() {}

	/**
	 *	Returns the <code>message</code> field, the ASCII or UTF-8 text of
	 *	the message itself.
	 *
	 *	@return			message text
	 *	@since			1.0
	 */
	public String getMessage() {}

	/**
	 *	Returns the <code>timestamp</code> field, which is used by some message
     *	types, for example off-line messages. (If unused, it will be null).
	 *
	 *	@return			date as <code>Date</code> object
	 *	@since			1.0
	 */
	public Date getTimestamp() {}

	/**
	 *	Returns the status as presented in the Yahoo packet header.  Most
	 *	event types don't require this to be inspected, and indeed currently
	 *	the jYMSG API only bothers to set this on a handful of events.
	 *
	 *	@return			status, see <code>StatusConstants</code> interface
	 *	@since			1.0
	 */
	public long getStatus() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 *	@since			1.0
	 */
	public String toString() {}
}
