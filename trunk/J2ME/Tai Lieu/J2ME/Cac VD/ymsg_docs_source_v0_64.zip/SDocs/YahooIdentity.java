package ymsg.network;

/**
 *	Represents an alias to the current Yahoo account.
 *	<p>
 *	A list of possible aliases (identities) is given to the session as part
 *	of the login process.  The list can be accessed at any time from the 
 *	<code>getIdentities</code> method of a current <code>Session</code> object.
 *	Typically this list is made available to an end user via some sort of menu.  
 *	Clients would use the <code>YahooIdentity</code> associated with the 
 *	choosen menu item when calling methods on the <code>Session</code> 
 *	overloaded to take an identity.
 *	<p>
 *	The order in which identities appear in the list may change from login to
 *	login.  Indeed even during a session, if the user's data is refreshed, 
 *	there is a (slim) possibility they may change order.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class YahooIdentity
{	/**
	 *	Returns this identity's username.
	 *
 	 *	@return			identity string
	 *	@since			1.0
	 */
	public String getId() {}
	/**
	 *	Returns true if this is the primary identity.  The primary
	 *	identity is the original, true, identity.  All other identities are
	 *	aliases to the primary identity.
	 *
 	 *	@return			true if object is user's primary identity
	 *	@since			1.0
	 */
	public boolean isPrimaryIdentity() {}
	/**
	 *	Returns true if this is the login identity.  The login identity is
	 *	the username used with the <code>Session.login</code> method to 
	 *	create the current session.
	 *
 	 *	@return			true if object is user's login identity
	 *	@since			1.0
	 */
	public boolean isLoginIdentity() {}
	/**
	 *	Returns true if this identity is currently activated.  Activated
	 *	identities are visible to the network, while deactivated identities
	 *	appear as if they are off-line.
	 *
 	 *	@return			true if the identity is active
	 *	@since			1.0
	 */
	public boolean isActivated() {}

	/**
	 *	Returns a string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
