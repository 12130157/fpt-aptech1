package ymsg.network;

/**
 *	Is thrown when the jYMSG API fails to decode an incoming packet due
 *	to incorrect or unexpected formatting.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class YMSG9BadFormatException extends YahooException
{	YMSG9BadFormatException(String m,boolean b) {}
	YMSG9BadFormatException(String m) {}
	YMSG9BadFormatException(String m,boolean b,Throwable ex) {}

	/**
	 *	Returns the exception which cause this exception.
	 *
	 *	@return			exception
	 *	@since			1.0
	 */
	public Throwable getCausingThrowable() {}
}
