package ymsg.network;

import java.util.*;
import java.io.*;
import java.net.Socket;

/**
 *	Connection handler for HTTP proxy connections to Yahoo.  Pass this
 *	class into the <code>Session</code> constructor to create a session
 *	which can work through firewalls.
 *	<p>
 *	<i>Warning: HTTP is notoriously unreliable, even for geniune Yahoo,
 *	software.  Not all problems with this class stem from bugs in its
 *	code.  Hopefully future revisions of this handler will be able to
 *	smooth out any problems, or at least report them to the application
 *	better.</i>
 *	<p>
 *	For more information on the Java properties used by this class, read
 *	<a href="http://java.sun.com/j2se/1.4.2/docs/guide/net/properties.html">Sun's
 *	Java Networking Properties</a> page.
 *	<p>
 *	There is a system properties which alters the target of a connection.
 *	<code>ymsg.network.httpHost</code> can be used to set the host to
 *	which the connection will be made.  In reality is it highly unlikely
 *	that this property should need to be changed from its default:
 *	<code>http.pager.yahoo.com</code>.
 *	<p>
 *	For users who access Yahoo from behind a firewall which requires
 *	HTTP proxy authorization, the property <code>ymsg.network.httpProxyAuth</code>
 *	can be used to set content for the <code>Proxy-Authorization</code>
 *	HTTP header.  A typical value (using the basic encoding scheme) might
 *	look something like <code>Basic Ab0Cd1Ef2Gh3z9==</code>, where the
 *	second part is the proxy username followed by a colon followed by the
 *	proxy password, encoded using BASE64.  (Alternative encoding schemes
 *	may take different forms.)
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class HTTPConnectionHandler extends ConnectionHandler
implements ServiceConstants
{	/**
	 *	Connect using the Java system properties <code>http.proxyHost</code>
	 *	and <code>http.proxyPort</code>.  If host is unset, this constructor
	 *	will look for the old (pre Java2 v1.3) names of <code>proxyHost</code>
	 *	and <code>proxyPort</code>.  If these are also unset, this constructor
	 *	will throw an <code>IllegalArgumentException</code>.
	 *
	 *	@throws IllegalStateException If no HTTP proxy properties set
	 *	@since			1.0
	 */
	public HTTPConnectionHandler() throws IllegalArgumentException {}
	/**
	 *	Connect using a specific HTTP proxy host and port, with a list
	 *	of excempt hosts.
	 *	<p>
	 *	<i>Note: this constructor sets the Java system properties
	 *	<code>http.proxyHost</code>, <code>http.proxyPort</code>,
	 *	<code>proxyHost</code>, <code>proxyPort</code>, and
	 *	<code>http.nonProxyHosts</code>.  These settings will be global
	 *	throughout the JVM.</i>
	 *	<p>
	 *	<i>Note: <code>http.nonProxyHosts</code> is unsupported in Java
	 *	prior to Java2 v1.3.</i>
	 *
	 *	@param ph		proxy host
	 *	@param pp		proxy port
	 *	@param ex		proxy exemption list, pipe char separated.
	 *	@since			1.0
	 */
	public HTTPConnectionHandler(String ph,int pp,String ex) {}
	/**
	 *	Connect using a specific HTTP proxy host and port, with a list
	 *	of excempt hosts, as a Vector.  (The list is converted into the
	 *	usual pipe separated String format.)
	 *	<p>
	 *	<i>Note: this constructor sets the Java system properties
	 *	<code>http.proxyHost</code>, <code>http.proxyPort</code>,
	 *	<code>proxyHost</code>, <code>proxyPort</code>, and
	 *	<code>http.nonProxyHosts</code>.  These settings will be global
	 *	throughout the JVM.</i>
	 *	<p>
	 *	<i>Note: <code>http.nonProxyHosts</code> is unsupported in Java
	 *	prior to Java2 v1.3.</i>
	 *
	 *	@param ph		proxy host
	 *	@param pp		proxy port
	 *	@param ex		proxy exemption list, one host per element
	 *	@since			1.0
	 */
	public HTTPConnectionHandler(String ph,int pp,Vector ex) {}
	/**
	 *	Connect using a specific HTTP proxy host and port, with no
	 *	excempt hosts.
	 *	<p>
	 *	<i>Note: this constructor sets the Java system properties
	 *	<code>http.proxyHost</code>, <code>http.proxyPort</code>,
	 *	<code>proxyHost</code>, <code>proxyPort</code>, and
	 *	<code>http.nonProxyHosts</code>.  These settings will be global
	 *	throughout the JVM.</i>
	 *	<p>
	 *	<i>Note: <code>http.nonProxyHosts</code> is unsupported in Java
	 *	prior to Java2 v1.3.</i>
	 *
	 *	@param ph		proxy host
	 *	@param pp		proxy port
	 *	@since			1.0
	 */
	public HTTPConnectionHandler(String ph,int pp) {}

	/**
	 *	Returns the string representation of this object.
	 *
	 *	@return			object as a string
	 */
	public String toString() {}
}
