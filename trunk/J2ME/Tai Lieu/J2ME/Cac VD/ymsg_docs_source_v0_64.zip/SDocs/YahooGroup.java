package ymsg.network;

import java.util.Vector;

/**
 *	Represents a single group of users on the friends list.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class YahooGroup
{	/**
	 *	Get the group name.
	 *	
	 *	@return			Group name
	 *	@since			1.0
	 */
	public String getName() {}

	/**
	 *	Returns whether the group is currently open on the user interface.  The
	 *	open status is not used by the API (as yet) but is the recommended
	 *	way to determine whether the tree branch on the user interface which
	 *	represents this group is open (showing) or close (collapsed).
	 *	
	 *	@return			Group name
	 *	@see			#setOpen(boolean b)
	 *	@since			1.0
	 */
	public boolean isOpen() {}

	/**
	 *	Sets the open state of this group on the user interface.  The
	 *	open status is not used by the API (as yet) but is the recommended
	 *	way to determine whether the tree branch on the user interface which
	 *	represents this group is open (showing) or close (collapsed).
	 *	
	 *	@param b		true=open, false=closed
	 *	@see			#isOpen()
	 *	@since			1.0
	 */
	public void setOpen(boolean b) {}

	/**
	 *	Returns the current membership of this group.  The <code>Vector</code>
	 *	object returned should be populated with one or more <code>YahooUser</code>
	 *	objects, representing the users in the group at the time this method was
	 *	called.
	 *	<p>
	 *	<i>Note: this method makes a shallow clone of the internal membership 
	 *	array, and as such should be considered expensive.</i>
	 *	
	 *	@return			list of group members
	 *	@since			1.0
	 */
	public Vector getMembers() {}
	
	/**
	 *	Returns the index of a given friend with the specified ID in this
	 *	group.
	 *	
	 *	@param id		ID of friend
	 *	@return			Index of friend, or -1 if absent.
	 *	@since			1.0
	 */
	public synchronized int getIndexOfFriend(String id) {}

	/**
	 *	Returns a string representation of this object.
	 *	
	 *	@return			group as a string
	 *	@since			1.0
	 */
	public String toString() {}
}
