package ymsg.support;

import javax.swing.Icon;

/**
 *	Allows the intergration of bespoke smiley images as part of message
 *	decoding.
 *	<p>
 *	A concrete instance of this class can be used to supply icons to the
 *	message decoder code, for use when generating styled output which
 *	supports smileys.  If an <code>EmoticonLoader</code> is set, the
 *	<code>MessageDecoder</code> will defer all image loading to it first,
 *	but fall-back to its own default icons whenever the loader returns null.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public interface EmoticonLoader
{	/**
	 *	Load and return a given smiley icon.  There are currently 75 icons,
	 *	from 1 to 75.  Return either a Swing <code>Icon</code> instance, which
	 *	corresponds to the icon number (see the <code>Emoticons</code> class)
	 *	or null if the default icon is to be used. 
	 *
	 *	@param icon		integer from 1 to 35
	 *	@return			Icon object, or null
	 *	@since			1.0
	 */
	public Icon loadEmoticon(int icon);
}
