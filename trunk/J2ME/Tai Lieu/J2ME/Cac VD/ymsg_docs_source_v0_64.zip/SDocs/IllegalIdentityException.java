package ymsg.network;

/**
 *	Thrown when an invalid identity is passed to a method.  This should not
 *	happen, unless <code>YahooIdentity</code> objects are shared across
 *	sessions, an attempt is made to de/activate a primary identity, or
 *	one of the user's identities appears on the invite list of a conference.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class IllegalIdentityException extends java.lang.RuntimeException
{	IllegalIdentityException(String m) {}
}

