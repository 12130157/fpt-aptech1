package ymsg.support;

import java.awt.Color;
import java.awt.Font;
import java.util.*;

/**
 *	A mutable object model element which can be output as a Yahoo IM or
 *	chat encoded message.  This object is akin to a DOM element, acting
 *	as a container in the case of style types like bold, colours and fades;
 *	and a leaf in the case of texts.
 *	<pre><code>
 *	Root
 *	 |
 *	 +--Bold
 *	 |   |
 *	 |   +--Text ("Hello ")
 *	 |
 *	 +--Text ("world!")
 *	</code></pre>
 *	<p>
 *	The above four node'd tree, for example, would represent
 *	"<b>Hello </b>world!"
 *	<p>
 *	This class implements the interface <code>java.util.List</code> and
 *	contains all its list manipulation methods.  Use these to add and
 *	remove <code>MutableMessageElement</code> nodes to form a tree.
 *	<p>
 *	Please do not include classes other than <code>MutableMessageElement</code>
 *	(or a subclass) as nodes when building a tree.  Future implementations
 *	may employ Java 1.5's generics to enforce this restriction.
 *	<p>
 *	<i>Note: Yahoo appears to be in the process of changing over its escape
 *	based encoding scheme to something a little like XML tags.  So far
 *	examples of the new scheme have only been seen on chatrooms.  At some
 *	point this class should be modified to allow the switching between
 *	'old' and 'new' encoding styles...</i>
 *	<p>
 *	<table border="2" align="Center">
 *		<tr>
 *			<td align="Center">Name</td>
 *			<td align="Center">Old</td>
 *			<td align="Center">New</td>
 *		</tr>
 *		<tr>
 *			<td align="Left">Bold</td>
 *			<td align="Left">[esc]1m</td>
 *			<td align="Left">&lt;b&gt;</td>
 *		</tr>
 *		<tr>
 *			<td align="Left">Italic</td>
 *			<td align="Left">[esc]2m</td>
 *			<td align="Left">&lt;i&gt;</td>
 *		</tr>
 *		<tr>
 *			<td align="Left">Colour (enum)</td>
 *			<td align="Left">[esc]3<b>?</b>m</td>
 *			<td align="Left">&lt;'colour name'&gt;</td>
 *		</tr>
 *		<tr>
 *			<td align="Left">Colour (abs)</td>
 *			<td align="Left">[esc]3#RRGGBBm</td>
 *			<td align="Left">&lt;#RRGGBB&gt;</td>
 *		</tr>
 *		<tr>
 *			<td align="Left">Font</td>
 *			<td align="Left">&nbsp;</td>
 *			<td align="Left">&lt;font ... &gt;</td>
 *		</tr>
 *		<tr>
 *			<td align="Left">Fade</td>
 *			<td align="Left">&nbsp;</td>
 *			<td align="Left">&lt;fade ... &gt;</td>
 *		</tr>
 *		<tr>
 *			<td align="Left">Alt</td>
 *			<td align="Left">&nbsp;</td>
 *			<td align="Left">&lt;alt ... &gt;</td>
 *		</tr>
 *	</table>
 *	<p>
 *	<i>Note: Yahoo's colour escape codes do not work as containers - that is
 *	to say they do not have a close 'code' which undoes their effect.
 *	For as long as Yahoo uses escape codes rather than proper SGML-style
 *	containers (&lt;abc&gt;...&lt;/abc&gt;) this code offers overloaded methods to
 *	'fake' containers via a stack of colours, so that 'pseudo' end codes
 *	can be added by simply repeating the colour code above the 'closing'
 *	element in the stack.</i>
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class MutableMessageElement extends MessageElement implements java.util.List
{	/**
	 *	Creates a new MutableMessageElement defined as a root element.
	 *
	 *	@return			root container
	 *	@since			1.0
	 */
	public static MutableMessageElement createRoot() {}
	/**
	 *	Creates a new MutableMessageElement defined as a text element.
	 *
	 *	@param text		text content
	 *	@return			text element
	 *	@since			1.0
	 */
	public static MutableMessageElement createText(String text) {}
	/**
	 *	Creates a new MutableMessageElement defined as a bold element.
	 *
	 *	@return			bold container
	 *	@since			1.0
	 */
	public static MutableMessageElement createBold() {}
	/**
	 *	Creates a new MutableMessageElement defined as a italic element.
	 *
	 *	@return			italic container
	 *	@since			1.0
	 */
	public static MutableMessageElement createItalic() {}
	/**
	 *	Creates a new MutableMessageElement defined as a colour element.
	 *
	 *	@param idx		Yahoo colour index
	 *	@return			colour container
	 *	@since			1.0
	 */
	public static MutableMessageElement createIndexedColour(int idx) {}
	/**
	 *	Creates a new MutableMessageElement defined as a colour element.
	 *
	 *	@param n		Yahoo colour name
	 *	@return			colour container
	 *	@since			1.0
	 */
	public static MutableMessageElement createNamedColour(String n) {}
	/**
	 *	Creates a new MutableMessageElement defined as a colour element.
	 *
	 *	@param c		absolute colour as AWT Color
	 *	@return			colour container
	 *	@since			1.0
	 */
	public static MutableMessageElement createAbsoluteColour(Color c) {}
	/**
	 *	Creates a new MutableMessageElement defined as a underline element.
	 *
	 *	@return			underline container
	 *	@since			1.0
	 */
	public static MutableMessageElement createUnderline() {}
	/**
	 *	Creates a new MutableMessageElement defined as a font element.
	 *
	 *	@param f		AWT font object
	 *	@return			font container
	 *	@since			1.0
	 */
	public static MutableMessageElement createFont(Font f) {}
	/**
	 *	Creates a new MutableMessageElement defined as a fade element.
	 *
	 *	@param c		array of AWT Color objects
	 *	@return			fade container
	 *	@since			1.0
	 */
	public static MutableMessageElement createFade(Color[] c) {}
	/**
	 *	Creates a new MutableMessageElement defined as a alt element.
	 *
	 *	@param c		array of AWT Color objects
	 *	@return			alt container
	 *	@since			1.0
	 */
	public static MutableMessageElement createAlt(Color[] c) {}



	/**
	 *	Returns the type of this element.  See the public data members in
	 *	this class's parent, <code>MessageElement</code>, for a list of
	 *	possible return values.
	 *
	 *	@return			element type
	 *	@since			1.0
	 */
	public int getType() {}
	/**
	 *	Returns the content from a text element.
	 *
	 *	@throws IllegalStateException if not a text element
	 *	@return			content text
	 *	@since			1.0
	 */
	public String getText() throws IllegalStateException {}
	/**
	 *	Sets content in a text element.
	 *
	 *	@throws IllegalStateException if not a text element
	 *	@param t		content text
	 *	@since			1.0
	 */
	public void setText(String t) throws IllegalStateException {}
	/**
	 *	Returns the content from an index colour element.
	 *
	 *	@throws IllegalStateException if not an index colour element
	 *	@return			content index
	 *	@since			1.0
	 */
	public int getIndexedColour() throws IllegalStateException {}
	/**
	 *	Sets content in an indexed colour element.
	 *
	 *	@throws IllegalStateException if not an index colour element
	 *	@param i		content index
	 *	@since			1.0
	 */
	public void setIndexedColour(int i) throws IllegalStateException {}
	/**
	 *	Returns the content from a named colour element.
	 *
	 *	@throws IllegalStateException if not a named colour element
	 *	@return			content name
	 *	@since			1.0
	 */
	public String getNamedColour() throws IllegalStateException {}
	/**
	 *	Sets content in a named colour element.
	 *
	 *	@throws IllegalStateException if not a named colour element
	 *	@param n		content name
	 *	@since			1.0
	 */
	public void setNamedColour(String n) throws IllegalStateException {}
	/**
	 *	Returns the content from an absolute colour element.
	 *
	 *	@throws IllegalStateException if not an absolute colour element
	 *	@return			content AWT Color
	 *	@since			1.0
	 */
	public Color getAbsoluteColour() throws IllegalStateException {}
	/**
	 *	Sets content in an absolute colour element.
	 *
	 *	@throws IllegalStateException if not an absolute colour element
	 *	@param c		content AWT Color
	 *	@since			1.0
	 */
	public void setAbsoluteColour(Color c) throws IllegalStateException {}
	/**
	 *	Returns the content from a font element.
	 *
	 *	@throws IllegalStateException if not a font element
	 *	@return			content AWT Font
	 *	@since			1.0
	 */
	public Font getFont() throws IllegalStateException {}
	/**
	 *	Sets content in a font element.
	 *
	 *	@throws IllegalStateException if not a font element
	 *	@param f		content AWT Font
	 *	@since			1.0
	 */
	public void setFont(Font f) throws IllegalStateException {}
	/**
	 *	Returns the content from a fade or alt element.
	 *
	 *	@throws IllegalStateException if not a fade or alt element
	 *	@return			content AWT Color array
	 *	@since			1.0
	 */
	public Color[] getTransition() throws IllegalStateException {}
	/**
	 *	Sets content in a fade or alt element.
	 *
	 *	@throws IllegalStateException if not a fade or alt element
	 *	@param c		content AWT Color array
	 *	@since			1.0
	 */
	public void setTransition(Color[] c)  throws IllegalStateException {}


	/**
	 *	Translates this message structure (from this node down) into a Yahoo
	 *	instant message.  Uncloseable containers are left open.
	 *
	 *	@return			message text
	 *	@since			1.0
	 */
	public String toYahooIM() {}
	/**
	 *	Translates this message structure (from this node down) into a Yahoo
	 *	instant message.  Uncloseable containers may be faked closed.
	 *	<p>
	 *	Old Yahoo colour encodings use escape codes, not SGML-style containers,
	 *	and as such there is no closing 'tag' to revert to the enclosing colour.
	 *	But the effect of a closing tag can be 'faked' by simply re-including
	 *	the parent escape code as a pseudo closing tag, to set the colour back
	 *	to the parent.
	 *	<p>
	 *	<i>Note: when Yahoo moves entirely to SGML-style message encoding, and
	 *	drops support from escape codes, it may be possible to deprecate this
	 *	method.</i>
	 *
	 *	@param fc		true will force containers closed
	 *	@return			message text
	 *	@since			1.0
	 */
	public String toYahooIM(boolean fc) {}
	/**
	 *	Translates this message structure (from this node down) into a Yahoo
	 *	chat message.  Uncloseable containers are left open.
	 *
	 *	@return			message text
	 *	@since			1.0
	 */
	public String toYahooChat() {}
	/**
	 *	Translates this message structure (from this node down) into a Yahoo
	 *	chat message.  Uncloseable containers may be faked closed.
	 *	<p>
	 *	Old Yahoo colour encodings use escape codes, not SGML-style containers,
	 *	and as such there is no closing 'tag' to revert to the enclosing colour.
	 *	But the effect of a closing tag can be 'faked' by simply re-including
	 *	the parent escape code as a pseudo closing tag, to set the colour back
	 *	to the parent.
	 *	<p>
	 *	<i>Note: when Yahoo moves entirely to SGML-style message encoding, and
	 *	drops support from escape codes, it may be possible to deprecate this
	 *	method.</i>
	 *
	 *	@param fc		true will force containers closed
	 *	@return			message text
	 *	@since			1.0
	 */
	public String toYahooChat(boolean fc) {}
}
