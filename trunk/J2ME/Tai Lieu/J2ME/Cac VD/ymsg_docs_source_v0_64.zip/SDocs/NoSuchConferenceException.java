package ymsg.network;

/**
 *	Thrown when the API is asked to do something with a conference which
 *	does not exist.  The <code>room</code> name is the identifier used to
 *	track conference messages.  When receiving an invite the room name
 *	(conference name) will be part of the event object.  When creating a
 *	conference ourselves, the room name will be returned by the
 *	<code>createConference</code> method.
 *
 *	@author		FISH
 *	@version	%I%, %G%
 *	@since		1.0
 */
public class NoSuchConferenceException extends java.lang.RuntimeException
{	NoSuchConferenceException(String m) {}
}
