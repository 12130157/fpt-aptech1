/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package demormiserver;

import interfaces.Reverseable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author tunn
 */
public class ReverseService extends UnicastRemoteObject implements Reverseable {
    private int count;
    public ReverseService() throws RemoteException {
        super();
    }

    public String call(String value) throws RemoteException{
        StringBuilder s=new StringBuilder(value);
        StringBuilder rs=s.reverse();
        count++;
        return rs.toString();
    }

    public int getCount() throws RemoteException {
        return count;
    }
}
