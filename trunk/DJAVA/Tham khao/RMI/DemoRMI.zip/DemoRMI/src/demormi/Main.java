/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package demormi;

import interfaces.Reverseable;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tunn
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            String txt = "Hello";
            String name;

            System.out.println("Nhap dich vu:");
            Scanner in=new Scanner(System.in);
            name=in.nextLine();

            Reverseable rs = (Reverseable) Naming.lookup("rmi://localhost:2020/"+name);

            System.out.println(rs.call(txt));
            System.out.println(rs.getCount());

        } catch (NotBoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (RemoteException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
