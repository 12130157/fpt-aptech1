/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package interfaces;
import java.rmi.Remote;
import java.rmi.RemoteException;
/**
 *
 * @author tunn
 */
public interface Reverseable extends Remote{
    public String call(String s) throws RemoteException;
    public int getCount() throws RemoteException;
}
