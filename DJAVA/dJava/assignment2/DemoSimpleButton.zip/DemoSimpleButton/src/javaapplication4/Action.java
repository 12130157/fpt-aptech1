/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication4;

/**
 *
 * @author tunn
 */
public interface Action {

    public void actionPerformed(Button aThis);

}
