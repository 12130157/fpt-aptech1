package ymsg.network;

public class NoSuchConferenceException extends java.lang.RuntimeException
{	NoSuchConferenceException(String m) { super(m); }
}
