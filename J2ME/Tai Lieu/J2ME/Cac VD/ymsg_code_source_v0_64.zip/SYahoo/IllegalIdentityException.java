package ymsg.network;

public class IllegalIdentityException extends java.lang.RuntimeException
{	IllegalIdentityException(String m) { super(m); }
}

